import CalcValleyFloorWidth

path = r"C:\temp\fpztest\example\KanawhaSeg_Route.gdb"
v = "Floodplain"
hydroname = "KanawhaSeg_Route"
CB_Offset = -999
CalcValleyFloorWidth.main(hydroname, path, v, CB_Offset)