import addlayertomap

# The following inputs are layers or table views: "transect_intersect_single"
transectint = r"C:\temp\fpztest\example\KanawhaSeg_Route.gdb\ValleyFloorWidth\transect_intersect_single"
arcpy.MakeFeatureLayer_management(transectint,"Valley Floor Intersect Pts Layer","Min = 'yes'","#","Seg_ID Seg_ID VISIBLE NONE;Min Min VISIBLE NONE")
addlayertomap.main("Valley Floor Intersect Pts Layer")