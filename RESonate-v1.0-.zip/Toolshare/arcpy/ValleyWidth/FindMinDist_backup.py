import arcpy, sys

def main(path, v):
    arcpy.env.overwriteOutput = True

    sitelocwpath = path + "\\sitelocations"

    IDList = []
    OIDDict = {}
    rows = arcpy.SearchCursor(sitelocwpath)
    row = rows.next()

    while row:
        SegId = row.getValue("Seg_ID")
        OID = row.getValue("OBJECTID")
        IDList.append(SegId)
        OIDDict[OID] = SegId
        row = rows.next()
    #print OIDDict
    del row, rows
# Create spatial join to get the orginal SegID
    if v == "Floodplain":
        transect_intersect_single="//ValleyFloorWidth//transect_intersect_single"
    elif v == "Microshed":
        transect_intersect_single="//ValleyWidth//transect_intersect_singleVW"
    elif v == "ChannelBelt":
        transect_intersect_single = "//ChannelBelt//transect_intersect_singleCB"

    transect = path + "//Transects//Transect_Simple"
    arcpy.SpatialJoin_analysis(path + transect_intersect_single,transect,path +transect_intersect_single + "_spatjoin" ,"JOIN_ONE_TO_ONE")
    arcpy.AddField_management(path +transect_intersect_single + "_spatjoin", "N_SEGID", "TEXT", "", "", "50")
    
    rows = arcpy.UpdateCursor(path + transect_intersect_single+ "_spatjoin")
    row = rows.next()
    while row:
        NearFID = row.getValue("NearFID")
        try:
            print int(NearFID)
            NearFID = int(NearFID)
            row.setValue("N_SEGID", OIDDict[NearFID])
            rows.updateRow(row)
            row = rows.next()
        except:
            row = rows.next()
    del row, rows

    #Check to see that Seg_ID = Org_ID if not then reset Seg_ID to -999
    rows = arcpy.UpdateCursor(path + transect_intersect_single+ "_spatjoin")
    row = rows.next()
    while row:
        SegID = row.getValue("Seg_ID")
        OrgID = row.getValue("N_SEGID")
        if SegID <> OrgID:
            row.setValue("Seg_ID", -999)
            rows.updateRow(row)
        row = rows.next()
    del row, rows

    MinList = []
    for id in IDList:
        if v == "Floodplain":
            transect_intersect_single="//ValleyFloorWidth//transect_intersect_single"+ "_spatjoin"
        elif v == "Microshed":
            transect_intersect_single="//ValleyWidth//transect_intersect_singleVW"+ "_spatjoin"
        elif v == "ChannelBelt":
            transect_intersect_single = "//ChannelBelt//transect_intersect_singleCB"+ "_spatjoin"

            
        rows = arcpy.SearchCursor(path + transect_intersect_single, "Seg_ID = '" + id + "'")
        row = rows.next()
        LeftObjectIDDict = {}
        LeftList = []
        RightList = []
        RightObjectIDDict = {}
        while row:
            ObjectID = row.getValue("OBJECTID")
            Side = row.getValue("side")
##            print "Side = " + Side
##            print "ObjectID = " + str(ObjectID)
            NearDist = row.getValue("NearDist")
            if Side == "left":
              LeftList.append(NearDist)
              LeftObjectIDDict[ObjectID] = NearDist
            elif Side == "right":
              RightList.append(NearDist)
              RightObjectIDDict[ObjectID] = NearDist
            row = rows.next()
        #Get the right and left minimums
       # print RightList
##        arcpy.AddMessage(RightList)
##        arcpy.AddMessage(LeftList)
        print id
        try:
            Rightmin = min(RightList)
            print Rightmin
        except:
            arcpy.AddMessage(id + " doesn't intersect " + v +" layer on right side")
        try:
            Leftmin= min(LeftList)
            print Leftmin
        except:
            arcpy.AddMessage(id + " doesn't intersect " + v +" layer on left side")

        for k in RightObjectIDDict.keys():
            result = RightObjectIDDict[k]
            
            if result == Rightmin:
                MinList.append(k)
                
        for k in LeftObjectIDDict.keys():
            result = LeftObjectIDDict[k]
            
            try:
                if result == Leftmin:
                    MinList.append(k)
            except:
                print "Error finding Leftmin not sure why, skipping out of it works fine"

            
    rows = arcpy.UpdateCursor(path + transect_intersect_single)
    row = rows.next()
##    arcpy.AddMessage(MinList)
    print MinList

    while row:
        ObjectID = row.getValue("OBJECTID")
        #print ObjectID
        #arcpy.AddMessage(ObjectID)
        if ObjectID in MinList:
           # print str(ObjectID) + " updated"
            row.setValue("Min", "yes")
            rows.updateRow(row)
        row = rows.next()
            
            
            
        
          
                

        