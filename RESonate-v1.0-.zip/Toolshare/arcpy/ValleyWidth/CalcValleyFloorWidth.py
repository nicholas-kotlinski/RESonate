import arcpy, sys, math
from math import sqrt, pow

def main(hydrolayername, path, v, CB_Offset):
    #Calculates Valley Floor Width using the minimum coordinates in the transect intersect single spatial join data layer.
    #path = r"C:\temp\fpztest\Kanawha_Sub2.gdb"
    if v == "Floodplain":
        transect_intersect_single_sj = path + "\\ValleyFloorWidth\\transect_intersect_single"+ "_spatjoin"
        transect_intersect_single = path + "\\ValleyFloorWidth\\transect_intersect_single"
        field = "ValFlrWidth"
    elif v == "Microshed":
        transect_intersect_single_sj = path + "\\ValleyWidth\\transect_intersect_singleVW"+ "_spatjoin"
        transect_intersect_single = path + "\\ValleyWidth\\transect_intersect_singleVW"
        field = "ValWidth"
    elif v == "ChannelBelt":
        transect_intersect_single_sj = path + "\\ChannelBelt\\transect_intersect_singleCB"+ "_spatjoin"
        transect_intersect_single = path + "\\ChannelBelt\\transect_intersect_singleCB"
        field = "CBWidth"
        

    IDList = []
    VFlDict = {}
    linklist = []
    rows = arcpy.SearchCursor(transect_intersect_single_sj, "Min = 'yes'")
    row = rows.next()

    while row:
        SegId = row.getValue("Seg_ID")
        if SegId not in IDList:
            IDList.append(SegId)
        targetid = row.getValue("Target_FID")
        linklist.append(targetid)
        row = rows.next()

    del row, rows

    #Get the coordinate values for the closest intersection points for each Segment.
    for id in IDList:
        rows = arcpy.SearchCursor(transect_intersect_single_sj, "Min = 'yes' AND Seg_ID= '" + id + "'")
        row = rows.next()
        X1 = ""
        Y1 = ""
        X2 = ""
        Y2 = ""
        while row:
            Side = row.getValue("side")
            XCoord = row.getValue("POINT_X")
            YCoord = row.getValue("POINT_Y")
            if Side == "left":
                X1 = XCoord
                Y1 = YCoord
            elif Side == "right":
                X2 = XCoord
                Y2 = YCoord
            row = rows.next()
        try:
            distance = sqrt(pow((X1 - X2), 2) + pow((Y1- Y2), 2))
            VFlDict[id] = distance
        except:
            arcpy.AddMessage(id + " doesn't intersect the " + v + " layer on one or more sides.")
            print id + " doesn't intersect the " + v + " layer on one or more sides."
            VFlDict[id] = -999

    del row, rows

    #Update the Width Lengths to the master table
    rows = arcpy.UpdateCursor(path + "\\" + hydrolayername + "_MasterTable")
    row = rows.next()
  
    while row:
        SegID = row.getValue("Seg_ID")
        try:
            width = VFlDict[SegID]
            if v == "ChannelBelt":

                if width == -999:
                    width = width
                else:
                    width = width - (CB_Offset*2)
                    if width < 0:
                        width = -999
        except:
            width = -999
        #print width
        row.setValue(field, width)
        rows.updateRow(row)
        row = rows.next()
    del row, rows
    #Calculate the ratio of Valley Width to Valley Floor Width once both have been calculated
    if v == "Microshed":
        rows = arcpy.UpdateCursor(path + "\\" + hydrolayername + "_MasterTable")
        row = rows.next()
        while row:
            ValFlrWidth = row.getValue("ValFlrWidth")
            ValWidth = row.getValue("ValWidth")
            ratio = ValWidth/ValFlrWidth
            if ratio > 0:
                row.setValue("RatioVWtoFW", ratio)
            else:
                row.setValue("RatioVWtoFW", -999)
            rows.updateRow(row)
            row = rows.next()
        del row, rows
    #Update Intersect points with min distance value

    for l in linklist:
        rows = arcpy.UpdateCursor(transect_intersect_single, "ObjectID = " + str(l))
        row = rows.next()

        while row:
            row.Min = "yes"
            rows.updateRow(row)
            row = rows.next()
        del row, rows
        
            
      
        
                

        