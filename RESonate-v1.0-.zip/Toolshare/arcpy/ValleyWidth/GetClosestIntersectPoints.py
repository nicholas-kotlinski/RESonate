import arcpy, sys, FindMinDist, time

def main(sitelocations,transect_intersect_single, v,HydroLayer):
    arcpy.env.overwriteOutput = True
    dsc = arcpy.Describe(sitelocations)
    path = dsc.path
    name = dsc.name
    sitelocwpath = path + "\\" + name
##    arcpy.AddMessage(transect_intersect_single)
    IDList = []
    rows = arcpy.SearchCursor(HydroLayer)
    row = rows.next()

    while row:
        Name = row.getValue("StreamName")
        IDList.append(Name)
        row = rows.next()

    arcpy.AddField_management(transect_intersect_single, "NearDist", "Double", "15", "8")
    arcpy.AddField_management(transect_intersect_single, "NearFID", "Double", "15", "8")

    if v == "Floodplain":
        singlepartlayer = "transect_intersect_single_lyr"
    elif v == "Microshed":
        singlepartlayer = "transect_intersect_singleVW_lyr"
    elif v == "ChannelBelt":
        singlepartlayer = "transect_intersect_singleCB_lyr"
        
    for id in IDList:
        arcpy.MakeFeatureLayer_management(sitelocations, "sitelocations_lyr")
##        arcpy.SelectLayerByAttribute_management( "sitelocations_lyr", "NEW_SELECTION", "Seg_ID = '" + id + "'" )
        arcpy.SelectLayerByAttribute_management("sitelocations_lyr", "NEW_SELECTION", "StreamName = '" + id + "'")
        arcpy.MakeFeatureLayer_management(transect_intersect_single, singlepartlayer)
##        arcpy.SelectLayerByAttribute_management(singlepartlayer, "NEW_SELECTION", "Seg_ID ='" + id + "'" )
        arcpy.SelectLayerByAttribute_management(singlepartlayer, "NEW_SELECTION", "Seg_ID Like '" + id + "%'")
        arcpy.Near_analysis(singlepartlayer,"sitelocations_lyr","#","NO_LOCATION","NO_ANGLE")
        arcpy.CalculateField_management(singlepartlayer,"NearDist","[NEAR_DIST]","VB","#")
        arcpy.CalculateField_management(singlepartlayer,"NearFID","[NEAR_FID]","VB","#")
        arcpy.AddField_management(singlepartlayer, "Min", "TEXT", "","", "5")
##        arcpy.AddMessage(id + " " + time.strftime("%Y-%m-%d %H:%M:%S")+ " complete" )
    FindMinDist.main(path, v)