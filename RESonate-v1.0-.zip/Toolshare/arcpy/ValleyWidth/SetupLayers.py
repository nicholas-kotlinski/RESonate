import arcpy, sys, GetClosestIntersectPoints, addlayertomap, CalcValleyFloorWidth, time

HydroLayer = sys.argv[1]
##HydroLayer = r"C:\temp\fpztest\forpres\KanawhaSeg_Route.shp"
path = sys.argv[2]
##path = r"C:\temp\fpztest\example\KanawhaSeg_Route.gdb"

dsc = arcpy.Describe(HydroLayer)
ext = dsc.Extension

if ext == "shp":
    hydronamewext = dsc.Name
    hydroname = hydronamewext.rstrip("." + ext)
else:
    hydroname = dsc.Name

mxd = arcpy.mapping.MapDocument("Current")
filepath = mxd.filePath

dscmxd = arcpy.Describe(filepath)
mxdname = dscmxd.name
filebasepath = dscmxd.path
mxdrootname = mxdname.replace(".mxd", "")
textfilepath = filebasepath + "\\"+ mxdrootname +"_RESdatalayers.txt"

textfile = open(textfilepath, "r")
wholething = textfile.read()
textlist = []
textlist = wholething.split("\n")
#Check for a channelbelt layer
ChannelBelt = textlist[7]

if ChannelBelt == "Channel bank is blank":
    arcpy.AddMessage("No Channel Belt")
    arcpy.AddMessage("Widths will be calculated for Valley Floor and Valley.")
    Variablelist = ["Floodplain", "Microshed"]
    CB_Offset = -999
else:
    Variablelist = ["Floodplain", "Microshed", "ChannelBelt"]
    CB_OffsetStr = textlist[8]
    CB_Offset, units = CB_OffsetStr.split(" ")
    CB_Offset = int(CB_Offset)
    #Variablelist = ["ChannelBelt"]    
    arcpy.AddMessage("Widths will be calculated for Valley Floor, Valley, and ChannelBank.")

for v in Variablelist:
    # Script arguments...

    if v == "Floodplain":
        Variable = textlist[5]
    elif v == "Microshed":
        Variable = textlist[6]
    elif v == "ChannelBelt":
        Variable = textlist[7]
    #arcpy.AddMessage(Floodplain)
    #check to see if Floodplain is added to data frame
    mxd = arcpy.mapping.MapDocument("Current")
    inmap = ""
    df = arcpy.mapping.ListDataFrames(mxd, "")[0]

    for lyr in arcpy.mapping.ListLayers(mxd, "",df):
        if lyr.name == Variable:
           inmap = "yes"
    if inmap <> "yes":
        arcpy.AddMessage(v + "layer needs to be added to map")

    else:
        arcpy.AddMessage(v + " layer exists!!!!")
        #variables
        transect =path + "\\Transects\\transect_simple"
        sitelocations = path + "\\sitelocations"
        if v == "Floodplain":
            transect_intersect =path+"//ValleyFloorWidth/transect_intersect"
            transect_intersect_single = path+"//ValleyFloorWidth/transect_intersect_single"
        elif v == "Microshed":
            transect_intersect =path+"//ValleyWidth/transect_intersectVW"
            transect_intersect_single = path+"//ValleyWidth/transect_intersect_singleVW"
        elif v == "ChannelBelt":
            transect_intersect = path +"//ChannelBelt/transect_intersectCB"
            transect_intersect_single = path + "//ChannelBelt/transect_intersect_singleCB"
            
        #Intersect transects with floodplain layer
        arcpy.Intersect_analysis(transect+" #;"+Variable+" #",transect_intersect,"ALL","#","POINT")
        #Split multipart into single part
        arcpy.MultipartToSinglepart_management(transect_intersect,transect_intersect_single)
        #Add XY coordinates to Singlepart result
        arcpy.AddXY_management(transect_intersect_single)
        
    arcpy.AddMessage("Moving on to Get Closest points at: " + time.strftime("%Y-%m-%d %H:%M:%S"))  
    GetClosestIntersectPoints.main(sitelocations,transect_intersect_single, v, HydroLayer)
    CalcValleyFloorWidth.main(hydroname, path, v, CB_Offset)
    inmap = ""
    for lyr in arcpy.mapping.ListLayers(mxd, "", df):
        if lyr.name == "sitelocations":
            inmap = "yes"

    if inmap <> "yes":
        lyrlist = [sitelocations, transect_intersect_single]
##        arcpy.AddMessage("Adding sitelocations and single intersect for " + v)
    else:
        lyrlist = [transect_intersect_single]
##        arcpy.AddMessage("Adding single intersect")
    for l in lyrlist:
        if l == sitelocations:
            addlayertomap.main(l)
        else:
            if v == "Floodplain":
                arcpy.MakeFeatureLayer_management(arcpy.MakeFeatureLayer_management(transect_intersect_single,"Valley Floor Intersect Pts Layer","Min = 'yes'","#","Seg_ID Seg_ID VISIBLE NONE;Min Min VISIBLE NONE"))
                addlayertomap.main("Valley Floor Intersect Pts Layer")
            if v== "Microshed":                                                  
                arcpy.MakeFeatureLayer_management(arcpy.MakeFeatureLayer_management(transect_intersect_single,"Valley Intersect Pts Layer","Min = 'yes'","#","Seg_ID Seg_ID VISIBLE NONE;Min Min VISIBLE NONE"))
                addlayertomap.main("Valley Intersect Pts Layer")
            if v == "ChannelBelt":
                arcpy.MakeFeatureLayer_management(arcpy.MakeFeatureLayer_management(transect_intersect_single,"Channel Belt Intersect Pts Layer","Min = 'yes'","#","Seg_ID Seg_ID VISIBLE NONE;Min Min VISIBLE NONE"))
                addlayertomap.main("Channel Belt Intersect Pts Layer")

mxd.save()
