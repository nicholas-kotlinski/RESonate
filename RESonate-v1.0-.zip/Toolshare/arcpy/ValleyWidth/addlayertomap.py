import arcpy

def main(layer):
##    desc = arcpy.Describe(layer)
##    shapetype = desc.shapeType
##    if shapetype == "Point":
##        loc = "Top"
##    elif shapetype =="Polyline":
    mxd = arcpy.mapping.MapDocument("Current")
    df = arcpy.mapping.ListDataFrames(mxd, "Layers") [0]
    addlayer = arcpy.mapping.Layer(layer)
    arcpy.mapping.AddLayer(df, addlayer, "AUTO_ARRANGE")
    