import arcpy, sys, math
from math import sqrt, pow
arcpy.env.overwriteOutput = True
HydroLayer = sys.argv[1]

path = sys.argv[2]

dsc = arcpy.Describe(HydroLayer)
hname = dsc.name
if "." in hname:
    hname = hname.replace(".shp", "")

hpath = dsc.CatalogPath
if ":" in HydroLayer:
    rows = arcpy.SearchCursor(HydroLayer)
else:
    rows = arcpy.SearchCursor(hpath + "//" + HydroLayer)

row = rows.next()
StreamNameList = []
while row:
    StreamName = row.getValue("StreamName")
    StreamNameList.append(StreamName)
    row = rows.next()
del row, rows

#Setup ObjectID and SegIDName Dictionary (this is due to weird bug in Spatial Join that is not taking the segID name)
rows = arcpy.SearchCursor(path + "//sitelocations")
row = rows.next()
ObjectIDDict = {}
while row:
    ObjectID = row.getValue("ObjectID")
    SegID = row.getValue("Seg_ID")
    ObjectIDDict[ObjectID] = SegID
    row = rows.next()
del row, rows

#Create feaure layers for Hydrology layer and sitelocations
arcpy.MakeFeatureLayer_management(HydroLayer, "Hydrolyr")
arcpy.MakeFeatureLayer_management(path + "//sitelocations", "SiteLocLyr")
count = 0
for s in StreamNameList:
     arcpy.MakeFeatureLayer_management(HydroLayer, "Hydrolyr","StreamName = '" +s + "'")
     arcpy.MakeFeatureLayer_management(path + "//sitelocations", "SiteLocLyr", "StreamName = '" +s + "'")
     StreamCount = arcpy.GetCount_management("Hydrolyr")
     arcpy.SelectLayerByAttribute_management("Hydrolyr","NEW_SELECTION", "StreamName = '" +s + "'")
     arcpy.SelectLayerByAttribute_management("SiteLocLyr", "NEW_SELECTION", "StreamName = '" +s + "'")
     StreamCount2 = arcpy.GetCount_management("Hydrolyr")

     #Split selected line by selected point(s)
     arcpy.SplitLineAtPoint_management("Hydrolyr","SiteLocLyr",path +"//RiverS//" + s +"_split5mselect","5 Meters")
     arcpy.SpatialJoin_analysis(path +"//RiverS//" + s +"_split5mselect","SiteLocLyr",path +"//RiverS//" + s +"_split5mselect_spatjoin","JOIN_ONE_TO_MANY","KEEP_ALL","StreamName StreamName true true false 254 Text 0 0 ,First,#,"+path +"//RiverS//" + s +"_split5mselect"+",StreamName,-1,-1;Seg_ID SegmentID true true false 50 Text 0 0 ,First,#,"+path +"//RiverS//" + s +"_split5mselect"+",Seg_ID,-1,-1;POINT_X POINT_X true true false 8 Double 0 0 ,First,#,"+ path +"//sitelocations,POINT_X,-1,-1;POINT_Y POINT_Y true true false 8 Double 0 0 ,First,#,"+ path +"//sitelocations,POINT_Y,-1,-1","INTERSECT","5 Meters","#")
    #Check to see that Spatial Join doesn't have an empty output
     NumCount = arcpy.GetCount_management(path +"//RiverS//" + s +"_split5mselect_spatjoin")
##     arcpy.AddMessage("Count for " + s + " is: " + str(int(NumCount.getOutput(0))))
    #Add NewID Field and Distance field to SplitLayer
     arcpy.AddField_management(path +"//RiverS//" + s +"_split5mselect", "Seg_ID", "Text", "", "", "70")
     arcpy.AddField_management(path + "//RiverS//" + s + "_split5mselect", "StrDist", "Double", "15", "8")
    # Add SegID to SpatJoin layer
     rows = arcpy.UpdateCursor(path +"//RiverS//" + s +"_split5mselect_spatjoin")
     row = rows.next()
     TargetFIDList = []
     
     while row:
        Join_Fid = row.getValue("JOIN_FID")
        LinkID = ObjectIDDict[Join_Fid]
        TargetFID = row.getValue("Target_FID")
        TargetFIDList.append(TargetFID)
        row.setValue("Seg_ID", LinkID)
        rows.updateRow(row)
        row = rows.next()
     del row, rows
    # Determine SegID related to Segment
     TDict = {}

     for t in TargetFIDList:
        rows = arcpy.UpdateCursor(path +"//RiverS//" + s +"_split5mselect_spatjoin", "Target_FID = " + str(t))
        row = rows.next()
        SegIDList = []
        fidcount = TargetFIDList.count(t)
        x = 0
        PointX2 = ""
        while row:
            SegID = row.getValue("Seg_ID")
            #print SegID
            StreamName = row.getValue("StreamName")
            SegIDList.append(SegID)
            if x == 0:
                PointX1 = row.getValue("Point_X")
                PointY1 = row.getValue("Point_Y")
            elif x == 1:
                PointX2 = row.getValue("Point_X")
                PointY2 = row.getValue("Point_Y")
            x = x + 1
            if PointX2 <> "":
                dist = sqrt(pow((PointX1 - PointX2),2) + pow((PointY1 - PointY2), 2))
                TDict[t] = dist
            else:
                if fidcount < 2:
                    #Create a feature layer with the segment and of the endpoints layer
                    arcpy.MakeFeatureLayer_management(path +"//RiverS//" + s +"_split5mselect_spatjoin", "RiverS_spatjoin","Target_FID = " + str(t))
##                    arcpy.AddMessage("Target_FID = " + str(t))
                    arcpy.MakeFeatureLayer_management(path +"//Transects//endpoints", "endpoints")
##                    arcpy.AddMessage("Made Feature Layer of endpoints")
                    #Select the endpoints that overlap the segment
                    arcpy.SelectLayerByLocation_management("endpoints","INTERSECT","RiverS_spatjoin","#","NEW_SELECTION")

                    rowsE = arcpy.SearchCursor("endpoints")
                    rowE = rowsE.next()

                    while rowE:
                        PointX2 = rowE.getValue("Point_X")
                        PointY2 = rowE.getValue("Point_Y")
                        rowE= rowsE.next()
                    del rowE, rowsE
##                    arcpy.AddMessage("Preparing to get distance")
##                    arcpy.AddMessage(PointX1)
##                    arcpy.AddMessage(PointX2)
                    dist = sqrt(pow((PointX1 - PointX2),2) + pow((PointY1 - PointY2), 2))
                    TDict[t] = dist
##                    arcpy.AddMessage("Finished selecting endpoint XY")
            row = rows.next()
##            del row, rows
            
        segdistlist = []
        #get the minumum distance to create SegID link to segment
        for seg in SegIDList:
            countscores = seg.count("_")
            if countscores == 1:
                name, segdist = seg.split("_")
                if "km" in segdist:
                    segdist = segdist.replace("km", "")
                    unit = "km"
                elif "m" in segdist:
                    segdist = segdist.replace("m", "")
                    unit = "m"
##                if segdist > 1:
##                    segdistlist.append(int(segdist))
##                elif segdist < 1:
                segdistlist.append(float(segdist))
            elif countscores == 2:
                name1, name2, segdist = seg.split("_")
                if "km" in segdist:
                    segdist = segdist.replace("km", "")
                    unit = "km"
                elif "m" in segdist:
                    segdist = segdist.replace("m", "")
                    unit = "m"
##                if segdist > 1:
##                    segdistlist.append(int(segdist))
##                elif segdist < 1:
                segdistlist.append(float(segdist))
                #segdistlist.append(int(segdist))
 

       
        mindist = min(segdistlist)
        if countscores == 1:
            newstring =  name +"_"+ str(mindist) + unit + ","
        elif countscores == 2:
            newstring =  name1 +"_"+ name2 + "_" + str(mindist) + unit + ","

        
        #newstring =  name +"_"+ str(mindist) + "km" + ","
        #print newstring
        secondstring = TDict[t]
       # print secondstring
        TDict[t] = newstring + str(secondstring)
        del row, rows

     rows = arcpy.UpdateCursor(path +"//RiverS//" + s +"_split5mselect")
     row = rows.next()
     while row:
        ObjectID = row.getValue("ObjectID")
        values = TDict[ObjectID]
        segid, distance = values.split(",")
        row.setValue("Seg_ID", segid)
        row.setValue("StrDist", distance)
        rows.updateRow(row)
        row = rows.next()
     del row, rows
    # Create feature layer to append all split layers into if this is the first layer
     if count == 0:
        arcpy.CopyFeatures_management(path +"//RiverS//" + s +"_split5mselect",path +"//RiverS//RiverSinuosity_split5m","#","0","0","0")
     else:
    #all other layers are appended to the new layer
        arcpy.Append_management(path +"//RiverS//" + s +"_split5mselect",path +"//RiverS//RiverSinuosity_split5m","NO_TEST","StreamName StreamName"" true true false 254 Text 0 0 ,First,#,"+ path +"//RiverS//" + s +"_split5mselect,StreamName,-1,-1;LengthKM ""LengthKM"" true true false 8 Double 0 0 ,First,#,"+ path +"//RiverS//" + s +"_split5mselect,LengthKM,-1,-1;Seg_ID ""Seg_ID"" true true false 70 Text 0 0 ,First,#,"+ path +"//RiverS//" + s +"_split5mselect,Seg_ID,-1,-1;StrDist ""StrDist"" true true false 8 Double 0 0 ,First,#,"+ path +"//RiverS//" + s +"_split5mselect,StrDist,-1,-1;Shape_Length ""Shape_Length"" false true true 8 Double 0 0 ,First,#,"+ path +"//RiverS//" + s +"_split5mselect,Shape_Length,-1,-1","#")
     count = count + 1

#Add Sinuosity field
arcpy.AddField_management(path +"//RiverS//RiverSinuosity_split5m", "Sinuosity", "Double", "15", "8")
SinuDict = {}
#Calculate Sinuosity field
rows = arcpy.UpdateCursor(path +"//RiverS//RiverSinuosity_split5m","StrDist <> -999")
row = rows.next()
while row:
    strDist = row.getValue("StrDist")
    rivDist = row.getValue("Shape_Length")
    SegId = row.getValue("Seg_ID")
    sinu = rivDist/strDist
    SinuDict[SegId] = sinu
    row.setValue("Sinuosity", sinu)
    rows.updateRow(row)
    row = rows.next()
del row, rows

#Calculate Sinuosity field to -999 if it is the end stream segment
rows= arcpy.UpdateCursor(path +"//RiverS//RiverSinuosity_split5m","StrDist = -999")
row = rows.next()

while row:
    SegID = row.getValue("Seg_ID")
    SinuDict[SegID] = -999
    row.setValue("Sinuosity", -999)
    rows.updateRow(row)
    row = rows.next()


#Update Sinuosity to Mastertable
rows=arcpy.UpdateCursor(path + "//" + hname + "_MasterTable")
row = rows.next()
#print SinuDict
while row:
    SegID = row.getValue("Seg_ID")
    try:
        sinuvalue = SinuDict[SegID]
    except:
        sinuvalue = -111
    row.setValue("SinuRC", sinuvalue)
    rows.updateRow(row)
    row = rows.next()
            
mxd = arcpy.mapping.MapDocument("Current")
mxd.save()
            
            
            

                 
         
     
