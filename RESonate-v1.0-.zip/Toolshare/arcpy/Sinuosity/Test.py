import arcpy, addlayertomap
path = r"C:\temp\fpztest\example\Kanawha_ClearFork_example.gdb\\"

arcpy.MakeFeatureLayer_management(path +"//RiverS//ClearFork_split5mselect_spatjoin", "RiverS_spatjoin","Target_FID = 1" )
arcpy.MakeFeatureLayer_management(path +"//Transects//endpoints", "endpoints")
addlayertomap.main("endpoints")
#Select the endpoints that overlap the segment
arcpy.SelectLayerByLocation_management("endpoints","INTERSECT","RiverS_spatjoin","#","NEW_SELECTION")

rowsE = arcpy.SearchCursor("endpoints")
rowE = rowsE.next()

while rowE:
    PointX2 = rowE.getValue("Point_X")
    PointY2 = rowE.getValue("Point_Y")
    rowE= rowsE.next()
del rowE, rowsE
arcpy.AddMessage("Preparing to get distance")
##arcpy.AddMessage(PointX1)
arcpy.AddMessage(PointX2)
##dist = sqrt(pow((PointX1 - PointX2),2) + pow((PointY1 - PointY2), 2))
##TDict[t] = dist
arcpy.AddMessage("Finished selecting endpoint XY")