import arcpy, sys, math
from math import sqrt, pow

arcpy.CheckOutExtension("3D")

Hydroname = sys.argv[1]

path = sys.argv[2]



dsc = arcpy.Describe(Hydroname)
ext = dsc.Extension

if ext == "shp":
    hydronamewext = dsc.Name
    hydroname = hydronamewext.rstrip("." + ext)
else:
    hydroname = dsc.Name

mxd = arcpy.mapping.MapDocument("Current")
filepath = mxd.filePath
dscmxd = arcpy.Describe(filepath)
mxdname = dscmxd.name
filebasepath = dscmxd.path
mxdrootname = mxdname.replace(".mxd", "")
textfilepath = filebasepath + "\\"+ mxdrootname +"_RESdatalayers.txt"

textfile = open(textfilepath, "r")
wholething = textfile.read()
textlist = []
textlist = wholething.split("\n")

#Get dem name from text file
DEM = textlist[2]
mxd = arcpy.mapping.MapDocument("Current")
inmap = ""
df = arcpy.mapping.ListDataFrames(mxd, "")[0]

for lyr in arcpy.mapping.ListLayers(mxd, "",df):
    if lyr.name == DEM:
       inmap = "yes"
if inmap <> "yes":
    arcpy.AddMessage("Elevation layer needs to be added to map")

#Check to see if Valley and Floor Width have been run
ValleyWidth = path +"\\ValleyWidth\\transect_intersect_singleVW_spatjoin"
ValleyFloorWidth = path +"\\ValleyFloorWidth\\transect_intersect_single_spatjoin"
if not arcpy.Exists(ValleyWidth):
##    arcpy.AddMessage("Step 3 - Calculate Widths MUST be run before running this tool")
    arcpy.AddError("Step 3 - Calculate Widths MUST be run before running this tool")
##    sys.exit()
    raise SystemExit, "Calculate Widths must be run before continuing"
    

lyrlist = [ValleyWidth, ValleyFloorWidth]
#Get the elevations for the 
for lyr in lyrlist:
    arcpy.AddSurfaceInformation_3d(lyr, DEM, "Z", "BILINEAR", "", "1", "0")

#Get a list of XY Coordinates related to transect for Valley Width
vwDict = {}
rows = arcpy.SearchCursor(ValleyWidth, "Min = 'yes'")
row = rows.next()
while row:
    TransectID = row.getValue("FID_Transect_Simple")
    XCoord = row.getValue("POINT_X")
    YCoord = row.getValue("POINT_Y")
    Elev = row.getValue("Z")
    vwDict[TransectID] = str(XCoord) + "," + str(YCoord) +","+ str(Elev)
    row = rows.next()
del row, rows

#Get a list of XY Coordinates related to transect for Valley Floor Width
vFLwDict = {}
rows = arcpy.SearchCursor(ValleyFloorWidth, "Min = 'yes'")
row = rows.next()
while row:
    TransectID = row.getValue("FID_Transect_Simple")
    XCoord = row.getValue("POINT_X")
    YCoord = row.getValue("POINT_Y")
    Elev = row.getValue("Z")
    vFLwDict[TransectID] = str(XCoord) + "," + str(YCoord) +","+ str(Elev)
    row = rows.next()
del row, rows
#print vwDict
# Calculate Slope and store the slope with the related SegID 
##if ":" in Transect:
##    rows = arcpy.SearchCursor(Transect)
##else:
##    rows = arcpy.SearchCursor(tpath)
rows = arcpy.SearchCursor(path + "\\Transects\\transect_simple")
leftSlopeDict = {}
rightSlopeDict = {}
row = rows.next()
while row:
    ObjectID = row.getValue("ObjectID")
    #print ObjectID
    Side = row.getValue("side")
    segID = row.getValue("Seg_ID")
# checked to see if Valley Width didn't have a value
    try:
        vwString = vwDict[ObjectID]
    except:
        vwString = "-999, -999, -999"
        
    X1,Y1, Z1 = vwString.split(",")
    X1 = float(X1)
    Y1 = float(Y1)
    Z1 = float(Z1)
    try:
        vFLwString = vFLwDict[ObjectID]
    except:
        vFLwString = "-999, -999, -999"
    X2, Y2, Z2 = vFLwString.split(",")
    X2 = float(X2)
    Y2 = float(Y2)
    Z2 = float(Z2)

    if X1 == -999:
        slope = -999
    else:
        distance = sqrt(pow((X1 - X2), 2) + pow((Y1- Y2), 2))
        slope = (Z1-Z2)/distance
    if Side == "left":
        leftSlopeDict[segID] = slope
    elif Side == "right":
        rightSlopeDict[segID] = slope
    row = rows.next()
del row, rows
        
#Update Slope into master table
MasterTable = path + "//" + hydroname + "_MasterTable"
rows = arcpy.UpdateCursor(MasterTable)
row = rows.next()

while row:
    SegID = row.getValue("Seg_ID")
    leftslope = leftSlopeDict[SegID]
    rightslope = rightSlopeDict[SegID]
    row.setValue("LftVSl", leftslope)
    row.setValue("RtVSl", rightslope)
    rows.updateRow(row)
    row = rows.next()
del row, rows

mxd.save()    
