import arcpy

def main (sitesimpleloc, SimpleSelectedVertices):

    rows = arcpy.SearchCursor(sitesimpleloc)
    row = rows.next()
    SegIDXDict = {}
    SegIDYDict = {}

    while row:
        SegID = row.getValue("Seg_ID")
        XCoord = row.getValue("Point_X")
        YCoord = row.getValue("Point_Y")
        SegIDXDict[SegID] = XCoord
        SegIDYDict[SegID] = YCoord
        row = rows.next()

    del row, rows
    # Update UpID X,Y coordinates
    rows = arcpy.UpdateCursor(SimpleSelectedVertices, "UpID IS NOT NULL")
    row = rows.next()

    while row:
        UpID = row.getValue("UpID")
        if UpID in SegIDXDict.keys():
            row.setValue("UpX", SegIDXDict[UpID])
            row.setValue("UpY", SegIDYDict[UpID])
        rows.updateRow(row)
        row = rows.next()

    del row, rows
    # Update DwnID X,Y coordinates
    rows = arcpy.UpdateCursor(SimpleSelectedVertices, "DwnID IS NOT NULL")
    row = rows.next()
    while row:
        DwnID = row.getValue("DwnID")
       # print DwnID
        if DwnID in SegIDXDict.keys():
            row.setValue("DwnX", SegIDXDict[DwnID])
            row.setValue("DwnY", SegIDYDict[DwnID])
        rows.updateRow(row)
        row = rows.next()
        