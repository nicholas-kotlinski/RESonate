import sys, string, os, arcpy, addlayertomap

def main (path, hydroname, SimplifyLayer, BendSimpleRoute, BendSimple_Route_Locate,simplifypts, SplitOutput):
    arcpy.env.overwriteOutput = True
    BendSimple_Route = path + "//" + hydroname+"_BendSimple_Route"
    #Create a route from the simplified river line
    arcpy.CreateRoutes_lr(SimplifyLayer, "StreamName", BendSimple_Route, "LENGTH", "", "", "UPPER_LEFT", "1", "0", "IGNORE", "INDEX")
    
    #variables
    #check to see if sitelocations have been added to the map if not add it
    sitelocations = "sitelocations"
    tablepath = path.rstrip("Transects")
    mxd = arcpy.mapping.MapDocument("Current")
    inmap = ""
    df = arcpy.mapping.ListDataFrames(mxd, "")[0]
    for lyr in arcpy.mapping.ListLayers(mxd, "",df):
        if lyr.name == "sitelocations":
           inmap = "yes"
    if inmap <> "yes":
        layer =  tablepath + "\\sitelocations"
        arcpy.AddMessage(layer)
        addlayertomap.main(layer)
    
    Output_Event_Table_Properties = "RID POINT MEAS"
    BendSimple_Route_Locate = tablepath + hydroname +"_BendSimple_Route_Locate"
##    arcpy.AddMessage(BendSimple_Route_Locate)
    Route_Locate_Events = hydroname + "BendSimple_Route_Locate_Events"
    SplitOutput = path + "\\" + hydroname + "_Simplify_split"

    # Process: Locate site locations along the simplified route line...
    arcpy.LocateFeaturesAlongRoutes_lr(sitelocations, BendSimple_Route, "StreamName", "2000 Meters", BendSimple_Route_Locate, Output_Event_Table_Properties, "FIRST", "DISTANCE", "ZERO", "FIELDS")    

    # Process: Make Route Event Layer of site locations along Simplified Route layer...
    arcpy.MakeRouteEventLayer_lr(BendSimple_Route, "StreamName", BendSimple_Route_Locate, "rid POINT meas", Route_Locate_Events, "", "NO_ERROR_FIELD", "NO_ANGLE_FIELD", "NORMAL", "ANGLE", "LEFT", "POINT")

     # Process: Convert Route Event layer of site locations to a new data layer...
    arcpy.FeatureClassToFeatureClass_conversion(Route_Locate_Events, path,"sitelocation_simplifypts", "", "RID 'RID' true true false 254 Text 0 0 ,First,#," + path + Route_Locate_Events + ",RID,-1,-1;MEAS 'MEAS' true true false 0 Double 0 0 ,First,#," + path + Route_Locate_Events + ",MEAS,-1,-1;Seg_ID 'Segment ID' true true false 50 Text 0 0 ,First,#," + path + Route_Locate_Events + ",Seg_ID,-1,-1;Units 'Units' true true false 5 Text 0 0 ,First,#," + path + Route_Locate_Events + ",Units,-1,-1;MeanAnnPreciip 'Mean Annual Precip' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",MeanAnnPreciip,-1,-1;Geology 'Geology' true true false 50 Text 0 0 ,First,#," + path + Route_Locate_Events + ",Geology,-1,-1;Elev 'Elevation' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",Elev,-1,-1;ValWidth 'Valley Width' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",ValWidth,-1,-1;ValFlrWidth 'Valley Floor Width' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",ValFlrWidth,-1,-1;RatioVWtoFW 'Ratio VW to FW' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",RatioVWtoFW,-1,-1;LftVSl 'Left Valley Slope' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",LftVSl,-1,-1;RtVSl 'Right Valley Slope' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",RtVSl,-1,-1;DownVSl 'Down V Slope' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",DownVSl,-1,-1;SineLCB 'Sine L CB' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",SineLCB,-1,-1;SineRCB 'Sine R CB' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",SineRCB,-1,-1;CBWidth 'Channel Belt Width' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",CBWidth,-1,-1;SineRC 'Sine RC' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",SineRC,-1,-1;Planform 'Planform' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",Planform,-1,-1;Distance 'SampleDist' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",Distance,-1,-1;StreamName 'StreamName' true true false 100 Text 0 0 ,First,#," + path + Route_Locate_Events + ",StreamName,-1,-1;Seg_ID_US 'Segment ID Up' true true false 50 Text 0 0 ,First,#," + path + Route_Locate_Events + ",Seg_ID_US,-1,-1;Seg_ID_DS 'Segment ID Down' true true false 50 Text 0 0 ,First,#," + path + Route_Locate_Events + ",Seg_ID_DS,-1,-1;ORIG_FID 'ORIG_FID' true true false 4 Long 0 0 ,First,#," + path + Route_Locate_Events + ",ORIG_FID,-1,-1;POINT_X 'POINT_X' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",POINT_X,-1,-1;POINT_Y 'POINT_Y' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",POINT_Y,-1,-1;POINT_M 'POINT_M' true true false 8 Double 0 0 ,First,#," + path + Route_Locate_Events + ",POINT_M,-1,-1;TestLink 'TestLink' true true false 4 Long 0 0 ,First,#," + path + Route_Locate_Events + ",TestLink,-1,-1;link 'link' true true false 4 Long 0 0 ,First,#," + path + Route_Locate_Events + ",link,-1,-1", "")
    simplifypts = path + "\\sitelocation_simplifypts"

    # Process: Split Line At Vertices in preparation to find the nearest stream lines...
    arcpy.SplitLine_management(BendSimple_Route, SplitOutput)
    
    # Process: Add Field...
    arcpy.AddField_management(SplitOutput, "UniqueID", "LONG", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

    # Process: Calculate Field...
    arcpy.CalculateField_management(SplitOutput, "UniqueID", "[OBJECTID]", "VB", "")

                          
    return BendSimple_Route, BendSimple_Route_Locate, simplifypts, SplitOutput
