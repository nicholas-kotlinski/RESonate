#GetClosestUpstreamDist.py
#Create the geoprocessor object
import os, arcpy, sys, CalcUpstreamDist, UpdateUpDwnXandY

def main(sitesimpleloc, SimpleSelectedVertices):
    fields = arcpy.ListFields(sitesimpleloc)
    l = ""
    dsc = arcpy.Describe(sitesimpleloc)
    path = dsc.path
    layerwpath = dsc.CatalogPath
    dbllist = ["UpX", "UpY", "DwnX", "DwnY", "Distance"]
    for d in dbllist:
        arcpy.AddField_management(SimpleSelectedVertices, d, "Double", "15", "8", "", "", "NULLABLE", "NON_REQUIRED", "")

    textlist = ["UpID", "DwnID", "Pos"]
    for t in textlist:
        if t <> "Pos":
            length = "50"
        else:
            length = "5"
        arcpy.AddField_management(SimpleSelectedVertices, t, "Text", "", "", length, "", "NULLABLE", "NON_REQUIRED", "")

    dcs2 = arcpy.Describe(SimpleSelectedVertices)
    SelectVwpath = dcs2.CatalogPath    

    rows = arcpy.UpdateCursor(layerwpath)
    row = rows.next()

    while row:
        SegID = row.getValue("Seg_ID")
        CenterX = row.getValue("Point_X")
        CenterY = row.getValue("Point_Y")
        Seg_ID_US = row.getValue("Seg_ID_US")
        Seg_ID_DS = row.getValue("Seg_ID_DS")   
        NearDist_link = row.getValue("NearDstlnk")
        rowsU = arcpy.UpdateCursor(SelectVwpath)
        rowU = rowsU.next()
        x = 0
        while rowU:
            ObjectID = rowU.getValue("Orig_FID")
            
            if ObjectID == NearDist_link:
                try:
                    if x == 0:
                        if Seg_ID_US <> "end":
                          rowU.setValue("UpID", Seg_ID_US)
                          
                        else:
                          rowU.setValue("DwnID", Seg_ID_DS)
                          rowU.setValue("UpID", "end")
                        x = 1
                    else:
                        if Seg_ID_US <> "end":
                          rowU.setValue("UpID", Seg_ID_US)
                        else:
                          rowU.setValue("DwnID", Seg_ID_DS)
                          rowU.setValue("UpID", "end")
                    rowsU.updateRow(rowU)
                except:
                    arcpy.AddMessage("Ran into an issue with " + SegID)
            rowU = rowsU.next()


        row = rows.next()

    del row, rows, rowU, rowsU
    #Get upstream and downstream coordinates
    UpdateUpDwnXandY.main(sitesimpleloc,SimpleSelectedVertices)

    arcpy.AddMessage("Calculating Upstream Distances")
    CalcUpstreamDist.main(sitesimpleloc, SimpleSelectedVertices)
