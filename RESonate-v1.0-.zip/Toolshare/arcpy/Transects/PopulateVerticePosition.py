import os, arcpy, sys

def main (SimpleSelectedVertices, u, dir):
    dcs2 = arcpy.Describe(SimpleSelectedVertices)
    SelectVwpath = dcs2.CatalogPath
    rowsU = arcpy.UpdateCursor(SelectVwpath)
    rowU = rowsU.next()
    while rowU:
        ObjectID =  rowU.getValue("ObjectID")

        if u == ObjectID:
            rowU.setValue("Pos", dir)
            rowsU.updateRow(rowU)
            break

        rowU = rowsU.next()