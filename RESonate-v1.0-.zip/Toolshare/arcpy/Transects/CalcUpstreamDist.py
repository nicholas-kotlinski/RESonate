
import os, arcpy, sys, math, PopulateVerticePosition
from math import sqrt, pow

def main(sitesimpleloc, SimpleSelectedVertices):
    fields = arcpy.ListFields(sitesimpleloc)
    l = ""
    dsc = arcpy.Describe(sitesimpleloc)
    path = dsc.path
    layerwpath = dsc.CatalogPath

    dcs2 = arcpy.Describe(SimpleSelectedVertices)
    SelectVwpath = dcs2.CatalogPath    


    rows = arcpy.UpdateCursor(layerwpath)
    row = rows.next()
    uplist = []
    downlist = []
    distance1 = 0
    distance2 = 0
    while row:
        Seg_ID_US = row.getValue("Seg_ID_US")
        Seg_ID_DS = row.getValue("Seg_ID_DS")  
        NearDist_link = row.getValue("NearDstlnk")
        rowsU = arcpy.UpdateCursor(SelectVwpath)
        rowU = rowsU.next()

        x = 0
        while rowU:
            ObjectID = rowU.getValue("Orig_FID")
            
            if ObjectID == NearDist_link:
                if x == 0:
                    if Seg_ID_US <> "end" and Seg_ID_US <> "None":
                      print Seg_ID_US
                      ObjectId1 = rowU.getValue("ObjectID")
                      vX = rowU.getValue("Point_X")
                      print "Point X = " + str(vX)
                      vY = rowU.getValue("Point_Y")
                      print "Point Y = " + str(vY)
                      UpX = rowU.getValue("UpX")
                      print "UpX= " + str(UpX)
                      UpY = rowU.getValue("UpY")
                      print "UpY= " + str(UpY)
                      distance1 = sqrt(pow((vX - UpX),2) + pow((vY - UpY), 2))
                      rowU.setValue("Distance", distance1)        
                    else:
                      ObjectId1 = rowU.getValue("ObjectID")
                      vX = rowU.getValue("Point_X")
                      vY = rowU.getValue("Point_Y")
                      DwnX = rowU.getValue("DwnX")
                      DwnY = rowU.getValue("DwnY")
                      distance1 = sqrt(pow((vX - DwnX),2) + pow((vY - DwnY), 2))
                      rowU.setValue("Distance", distance1)  
                    x = 1
                else:
                    if Seg_ID_US <> "end":
                      ObjectId2 = rowU.getValue("ObjectID")
                      vX = rowU.getValue("Point_X")
                      vY = rowU.getValue("Point_Y")
                      UpX = rowU.getValue("UpX")
                      UpY = rowU.getValue("UpY")
                      distance2 = sqrt(pow((vX - UpX),2) + pow((vY - UpY), 2))
                      rowU.setValue("Distance", distance2)    
                    else:
                      try:
                          ObjectId2 = rowU.getValue("ObjectID")
                          vX = rowU.getValue("Point_X")
                          vY = rowU.getValue("Point_Y")
                          DwnX = rowU.getValue("DwnX")
                          DwnY = rowU.getValue("DwnY")
                          distance2 = sqrt(pow((vX - DwnX),2) + pow((vY - DwnY), 2))
                          rowU.setValue("Distance", distance2)
                      except:
                          arcpy.AddMessage(ObjectId2)
                    x = 2
                      
                rowsU.updateRow(rowU)
                if x ==2:
                    if Seg_ID_US <> "end":
                       # print distance1
                       # print distance2
                        if distance1 < distance2:
                            uplist.append(ObjectId1)
                            downlist.append(ObjectId2)
                        else:
                            uplist.append(ObjectId2)
                            downlist.append(ObjectId1)
                    elif Seg_ID_US == "end":
                        if distance1 < distance2:
                            uplist.append(ObjectId2)
                            downlist.append(ObjectId1)
                        else:
                            uplist.append(ObjectId1)
                            downlist.append(ObjectId2)
            rowU = rowsU.next()

        row = rows.next()

    del row, rows, rowU, rowsU

    for u in uplist:

        dir = "up"
        PopulateVerticePosition.main(SimpleSelectedVertices, u, dir)

    for d in downlist:
        dir = "down"
        PopulateVerticePosition.main(SimpleSelectedVertices, d, dir)

        
