    # Import system modules
import sys, string, os, arcpy
    
  
    # Local variables...
    
def main (UpX, UpY, DwnX, DwnY, CenterX, CenterY, counter, textfile, pttextfile, distance):

    slope = 0
   
    #Create a text file and write polylines to the first line.
    f = open(textfile,'a')
    thestring = "polyline\n"
    f.writelines(thestring)
    f.close()   
    midx = float(CenterX)
    midy = float(CenterY)
    starty = float(UpY)
    startx = float(UpX)
    endy = float(DwnY)
    endx = float(DwnX)
        
        #if the line is horizontal or vertical the slope and negreciprocal will fail so do this instead.
    if starty==endy or startx==endx:
            if starty == endy:
                y1 = midy + distance
                y2 = midy - distance
                x1 = midx
                x2 = midx
    
            if startx == endx:
                y1 = midy
                y2 = midy 
                x1 = midx + distance
                x2 = midx - distance
        
        
    else:
        
            #get the slope of the line
            m = ((starty - endy)/(startx - endx))
            
            #get the negative reciprocal, 
            negativereciprocal = -1*((startx - endx)/(starty - endy))
            
            if m > 0:
                slope = m
                #increase x values, find y
                if m >= 1:
                    y1 = negativereciprocal*(distance)+ midy
                    y2 = negativereciprocal*(-distance) + midy
                    x1 = midx + distance
                    x2 = midx - distance
                #increase y find x
                if m < 1:
                    y1 = midy + distance
                    y2 = midy - distance
                    x1 = (distance/negativereciprocal) + midx
                    x2 = (-distance/negativereciprocal)+ midx
                    
            if m < 0:
                slope = m
                #add to x find y
                if m >= -1:
                #add to y find x
                    y1 = midy + distance
                    y2 = midy - distance
                    x1 = (distance/negativereciprocal) + midx
                    x2 = (-distance/negativereciprocal)+ midx  
                
                if m < -1:
                    y1 = negativereciprocal*(distance)+ midy
                    y2 = negativereciprocal*(-distance) + midy
                    x1 = midx + distance
                    x2 = midx - distance

            
    f = open(textfile,'a')
    #thestring = str(counter) + " 0\n" + "0 "+ str(x1)+" "+str(y1) + "\n" + "1 " + str(x2) + " " + str(y2) +"\n"
    if DwnX - UpX >= 0:
        if y1 > y2:
            thestring = str(counter) + " 0\n" + "0 "+ str(x1)+" "+ str(y1) + "\n" + "1 " +str(midx) + " " + str(midy) +"\n"
            the2ndstring = str(counter) + " 0\n" + "0 " + str(midx) + " " + str(midy) + "\n" + "1 " + str(x2) + " " + str(y2) +"\n"
        else:
            the2ndstring = str(counter) + " 0\n" + "0 "+ str(x1)+" "+ str(y1) + "\n" + "1 " +str(midx) + " " + str(midy) +"\n"
            thestring = str(counter) + " 0\n" + "0 " + str(midx) + " " + str(midy) + "\n" + "1 " + str(x2) + " " + str(y2) +"\n"
    elif DwnX - UpX < 0:
        if y1 < y2:
            thestring = str(counter) + " 0\n" + "0 "+ str(x1)+" "+ str(y1) + "\n" + "1 " +str(midx) + " " + str(midy) +"\n"
            the2ndstring = str(counter) + " 0\n" + "0 " + str(midx) + " " + str(midy) + "\n" + "1 " + str(x2) + " " + str(y2) +"\n"
        else:
            the2ndstring = str(counter) + " 0\n" + "0 "+ str(x1)+" "+ str(y1) + "\n" + "1 " +str(midx) + " " + str(midy) +"\n"
            thestring = str(counter) + " 0\n" + "0 " + str(midx) + " " + str(midy) + "\n" + "1 " + str(x2) + " " + str(y2) +"\n"
            
    f.writelines(thestring)
    f.writelines(the2ndstring)
    f.close()
    f = open(pttextfile, 'a')
    if DwnX - UpX >= 0:
        if y1 > y2:
            thestring = str(counter) + "," + str(x1)+","+ str(y1) + "," + str(slope) + ",1st"+ ", highY"  + "\n"
            the2ndstring = str(counter) + "," + str(x2) + "," + str(y2) + "," + str(slope) + ",2nd" +", highY"  + "\n"
        else:
            the2ndstring = str(counter) + "," + str(x1)+","+ str(y1) + "," + str(slope) + ",2nd"+", highY"  + "\n"
            thestring = str(counter) + "," + str(x2) + "," + str(y2) + "," + str(slope) + ",1st" + ", highY"  + "\n"
    elif DwnX - UpX < 0:
        if y1 < y2:
            thestring = str(counter) + "," + str(x1)+","+ str(y1) + "," + str(slope) + ",1st"+", lowY"  + "\n"
            the2ndstring = str(counter) + "," + str(x2) + "," + str(y2) + "," + str(slope) + ",2nd" +", lowY"  + "\n"
        else:
            the2ndstring = str(counter) + "," + str(x1)+","+ str(y1) + "," + str(slope) + ",2nd"+", lowY"  + "\n"
            thestring = str(counter) + "," + str(x2) + "," + str(y2) + "," + str(slope) + ",1st" + ", lowY"  + "\n"


    f.writelines(thestring)
    f.writelines(the2ndstring)
    f.close()
    del x1
    del x2
    del y1
    del y2
        
    counter = counter + 1
 
    
   
   