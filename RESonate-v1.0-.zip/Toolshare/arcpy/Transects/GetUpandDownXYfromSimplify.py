#Create the geoprocessor object
import os, arcpy, sys, CalculatePerpendicularLines_simplify_directional, arcgisscripting

def main(sitesimpleloc, SimpleSelectedVertices, transects, hydroname, basepath, transectpts, distance):
    Counter = 1

    fields = arcpy.ListFields(sitesimpleloc)
    l = ""
    for field in fields:
        a = field.name
        if a == "link":
            l = "lengthfound"
            arcpy.AddMessage ("field found")
           # print "field found"
    if l == "":
        arcpy.AddField_management(sitesimpleloc, "link", "LONG", "9", "", "", "", "NULLABLE", "NON_REQUIRED", "")
##        arcpy.AddMessage("Field not found")

    #get path
    dsc = arcpy.Describe(sitesimpleloc)
    path = dsc.path
    layerwpath = dsc.CatalogPath

    dcs2 = arcpy.Describe(SimpleSelectedVertices)
    SelectVwpath = dcs2.CatalogPath    

    rows = arcpy.UpdateCursor(layerwpath)
    row = rows.next()

    # Create text file to be used to record coordinates
    intpath = basepath.rstrip("\\")
    homepath = intpath.rstrip(hydroname+".gdb")
    textfile = homepath +"transect_simplify_" + hydroname +".txt"
    pttextfile = homepath +"transect_simplify_" + hydroname +"_pts.txt"
    arcpy.AddMessage("The transect text file is saved here: " + textfile)
    file(textfile, 'wt')
    file(pttextfile, 'wt')
    f = open(pttextfile,'a')
    thestring = "Point,X,Y,Slope,Pos,Loc\n"
    f.writelines(thestring)
    f.close()   

    while row:
        SegID = row.getValue("Seg_ID")
        CenterX = row.getValue("Point_X")
        CenterY = row.getValue("Point_Y")
        NearDist_link = row.getValue("NearDstlnk")
        rowsU = arcpy.SearchCursor(SelectVwpath)
        rowU = rowsU.next()
        x = 0
        while rowU:
            ObjectID = rowU.getValue("Orig_FID")
            
            if ObjectID == NearDist_link:
                if x == 0:
                    FirstX = rowU.getValue("Point_X")
                    FirstY = rowU.getValue("Point_Y")
                    Position = rowU.getValue("Pos")
                    x = 1
                else:
                    SecondX = rowU.getValue("Point_X")
                    SecondY = rowU.getValue("Point_Y")
            rowU = rowsU.next()
#Check to see if the First selected vertices is upstream or downstream of the second selected vertices
        if Position == "up":
            UpX = FirstX
            UpY = FirstY
            DwnX = SecondX
            DwnY = SecondY
        elif Position == "down":
            UpX = SecondX
            UpY = SecondY
            DwnX = FirstX
            DwnY = FirstY
        
        CalculatePerpendicularLines_simplify_directional.main(UpX, UpY, DwnX, DwnY, CenterX, CenterY, Counter, textfile, pttextfile, distance)
        row.setValue("link",Counter)
        Counter = Counter + 1
        rows.updateRow(row)
        row = rows.next()
        
    tfiles = [textfile, pttextfile]
    for t in tfiles:
        f = open(t, 'a')
        thestring = "END"
        f.writelines(thestring)
        f.close()
    transects = path + "\\Transect_Simple"
    transectpts= path + "\\Transect_Simple_pts"

    # switch to arcgisscripting for this tool because ESRI got rid of a useful tool in 10
    gp= arcgisscripting.create(9.3)
    gp.CreateFeaturesFromTextFile(textfile, ".", transects, "#")

    arcpy.AddField_management(transects, "side", "text", "", "", "5", "", "NULLABLE", "NON_REQUIRED", "")
    rowsT = arcpy.UpdateCursor(transects)
    rowT = rowsT.next()
    while rowT:
        #Check to see if the ObjectID is even or odd if it is even then side is right, odd represents left
        ObjectID = rowT.getValue("ObjectID")
        if ObjectID%2 == 0:
            rowT.setValue("side", "right")
        else:
            rowT.setValue("side", "left")
        rowsT.updateRow(rowT)
        rowT = rowsT.next()
        
    
    arcpy.TableToDBASE_conversion(pttextfile, basepath)
##    arcpy.AddMessage(".dbf is saved here: " + basepath)

    
    del row, rows, rowU, rowsU

    #Join the SiteID field to the transects
    arcpy.JoinField_management(transects, "File_ID",layerwpath, "link","Seg_ID")

    return transects