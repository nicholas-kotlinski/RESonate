
import os, arcpy, sys

def main(sitesimpleloc, splitlayer, SplitVertices):

    dsc = arcpy.Describe(sitesimpleloc)
    layerwpath = dsc.CatalogPath

    ##Check to see if sitelocation has link field, if it doesn't add it.
    fields = arcpy.ListFields(sitesimpleloc)
    l = ""
    for field in fields:
        a = field.name
        if a == "NearDstlnk":
            l = "NearDstlnk found"
            arcpy.AddMessage (l)
    if l == "":
##        arcpy.AddMessage("NearDist_link field not Found")    
        arcpy.AddField_management(sitesimpleloc, "NearDstlnk", "LONG", "9", "", "", "", "NULLABLE", "NON_REQUIRED", "")
        arcpy.AddMessage("New Field added: NearDist_link")

    rows = arcpy.SearchCursor(layerwpath)
    row = rows.next()

    NameList = []

    while row:
        x = 0
        StreamName = row.getValue("StreamName")
        #Check to see if the list is empty
        if NameList ==[]:
            #if the list is empty add the stream name
            NameList.append(StreamName)
        else:
            #if the list is not empty check to see if the stream name is already in the list
            for n in NameList:
                if StreamName <> n:
                    x = x
                else:
                    x = x + 1
            #if the stream name is not already in the list add it to the list
            if x == 0:
                  NameList.append(StreamName)
               #   print StreamName + " added to list"
        row = rows.next()
        arcpy.MakeFeatureLayer_management(sitesimpleloc, "sitesimple")
        arcpy.MakeFeatureLayer_management(splitlayer, "splitlayer")
    for n in NameList:
        arcpy.SelectLayerByAttribute_management("sitesimple", "NEW_SELECTION", "StreamName = '" +n + "'")
        arcpy.SelectLayerByAttribute_management("splitlayer", "NEW_SELECTION", "StreamName = '" +n + "'")
    # Run Near calculation for selected set
        arcpy.Near_analysis("sitesimple", "splitlayer", "50 Meters", "NO_LOCATION", "NO_ANGLE")
        arcpy.CalculateField_management("sitesimple", "NearDstlnk", "[NEAR_FID]", "VB", "")

    arcpy.SelectLayerByAttribute_management("splitlayer", "CLEAR_SELECTION", "")
    rowsU = arcpy.SearchCursor(layerwpath)
    rowU = rowsU.next()

    #Select all streamlines near Site Locations
    while rowU:
        NearIDLink = rowU.getValue("NearDstlnk")
        arcpy.SelectLayerByAttribute_management("splitlayer", "ADD_TO_SELECTION", "ObjectID = " + str(NearIDLink))
        rowU =rowsU.next()

    #Convert selected lines to point vertices and add XY coords
    #Get the file path
    thefilepath = layerwpath
    path, fi = os.path.split(thefilepath)
    SplitVertices = path + "\\SimpleSelectedVertices"
    arcpy.FeatureVerticesToPoints_management(splitlayer, SplitVertices, "BOTH_ENDS")
    arcpy.AddXY_management (SplitVertices)
    arcpy.SelectLayerByAttribute_management("splitlayer", "CLEAR_SELECTION", "")
    arcpy.SelectLayerByAttribute_management("sitesimple", "CLEAR_SELECTION","")
    del row, rows, rowU, rowsU
    
    return SplitVertices
