# Import system modules
import sys, string, os, arcpy, CreateRoute, GetNearStreamLines, GetUpandDownXYfromSimplify, GetClosestUpstreamDist, addlayertomap

# Script arguments...
HydroLayer = sys.argv[1]
basepath = sys.argv[2]
SimplifyFactor = sys.argv[3]
Transectlength = sys.argv[4]
Tlength = str(Transectlength)
distance, units = Tlength.split(" ")
#Get the linear units from the Hydrolayer
sr = arcpy.Describe(HydroLayer).spatialReference
spunits = sr.LinearUnitName
#Convert the transect length distance to feet or meters depending on spatial reference
if spunits == "Meter":
    if units == "Kilometers":
        distance = float(distance)* 1000
    elif units == "Feet":
        distance = float(distance) * 0.3048
    elif units == "Meters":
        distance = float(distance) 
    else:
        arcpy.AddError("ERROR!!! Transect Distance must be in Kilometers, Meters, or Feet")
        raise SystemExit, "Script ended, please select Kilometers, Meters, or Feet"
elif "Foot" in spunits:
    if units == "Kilometers":
        distance = float(distance)* 3280.839895
    elif units == "Feet":
        distance = float(distance) 
    elif units == "Meters":
        distance = float(distance) * 3.280839895 
    else:
        arcpy.AddError("ERROR!!! Transect Distance must be in Kilometers, Meters, or Feet")
        raise SystemExit, "Script ended, please select Kilometers, Meters, or Feet"
else:
    arcpy.AddError("ERROR!!!! Your Hydrography layer is not projected!!")
    raise SystemExit, "Script ended, please project your hydrography layer"

distance = distance/2                   

path = basepath + "//Transects"
dsc = arcpy.Describe(HydroLayer)
ext = dsc.Extension

if ext == "shp":
    hydronamewext = dsc.Name
    hydroname = hydronamewext.rstrip("." + ext)
else:
    hydroname = dsc.Name

homepath = basepath.rstrip(hydroname+".gdb")
arcpy.AddMessage ("The homepath is:" + homepath)

# Local variables...
SimplifyLayer = path + "//" + hydroname +"_Simplify"
BendSimple_Route = ""
BendSimple_Route_Locate = ""
simplifypts = ""
splitlayer = ""
SplitOutput = ""
SplitVertices = ""
transects = ""
transectpts = ""
#Process: Simplify Line . . .
arcpy.SimplifyLine_cartography(HydroLayer, SimplifyLayer, "BEND_SIMPLIFY", SimplifyFactor, "FLAG_ERRORS", "NO_KEEP", "NO_CHECK")
arcpy.AddMessage("Stream Line has been simplified")

# Process: Create Routes and Simplify pts...
BendSimple_Route, BendSimple_Route_Locate,simplifypts, SplitOutput = CreateRoute.main(path, hydroname, SimplifyLayer, BendSimple_Route, BendSimple_Route_Locate, simplifypts, SplitOutput)

#Check to see if a too large of a simplify factor was used, if the counts don't match then a smaller simplify factor needs to be used
simpptscount = arcpy.GetCount_management(simplifypts)
siteloccount = arcpy.GetCount_management (basepath + "\\sitelocations")
splitcount = arcpy.GetCount_management(SplitOutput)
##arcpy.AddMessage("Simplept count = " + str(simpptscount))
##arcpy.AddMessage("Siteloc count = " + str(siteloccount))
##arcpy.AddMessage("Split count = " + str(splitcount))
if int(str(simpptscount)) <> int(str(siteloccount)):
    arcpy.AddError("ERROR!!! " + SimplifyFactor + " is too large please select a smaller one and rerun transect tool")
    raise SystemExit, "Script ended due to error"
if int(str(simpptscount)) > int(str(splitcount)):
    arcpy.AddError("ERROR!!! " + SimplifyFactor + " is too large please select a smaller one and rerun transect tool")
    raise SystemExit, "Script ended due to error"

arcpy.AddMessage ("Simplified Routes and points have been created")

#Process: Get Near Stream Lines
SplitVertices = GetNearStreamLines.main(simplifypts, SplitOutput,SplitVertices)
arcpy.AddMessage("Found the closest stream lines")

###Process: Populate Upstream and Downstream for Vertices for use in transect creation
GetClosestUpstreamDist.main(simplifypts, SplitVertices)
arcpy.AddMessage("Found up and downstream vertices")

###Process: Generate transects
transects = GetUpandDownXYfromSimplify.main(simplifypts,SplitVertices, transects, hydroname, basepath, transectpts, distance)
addlayertomap.main(transects)
mxd = arcpy.mapping.MapDocument("Current")
mxd.save()

