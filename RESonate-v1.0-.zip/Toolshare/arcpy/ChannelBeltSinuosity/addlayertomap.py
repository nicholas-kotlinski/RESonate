import arcpy

def main(layer):
    mxd = arcpy.mapping.MapDocument("Current")
    df = arcpy.mapping.ListDataFrames(mxd, "Layers") [0]
    addlayer = arcpy.mapping.Layer(layer)
    arcpy.mapping.AddLayer(df, addlayer, "BOTTOM")
    