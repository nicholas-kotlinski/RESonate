import TestLoop

path = r"C:\temp\fpztest\KansasTest\MedicineCreek.gdb"
MasterTable = r"C:\temp\fpztest\KansasTest\MedicineCreek.gdb\MedicineCreek_MasterTable"
CBIntersect = r"C:\temp\fpztest\KansasTest\MedicineCreek.gdb\ChannelBelt\transect_intersect_singleCB"
SpatialJoin = r"C:\temp\fpztest\KansasTest\MedicineCreek.gdb\ChannelBelt\\channelbeltsplit_spatjoin"
ChannelBelt = r"E:\FPZ\KansasData\Channel_Belt\ChannelBelt.gdb\offset\Channelbelt_Kansas_250offset"

TestLoop.main(MasterTable, CBIntersect, SpatialJoin, ChannelBelt, path)
