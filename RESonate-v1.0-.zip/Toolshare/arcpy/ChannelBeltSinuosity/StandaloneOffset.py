import arcpy, sys, addlayertomap

ChannelBelt = sys.argv[1]
##ChannelBelt = r"E:\FPZ\KansasData\Channel_Belt\ChannelBelt.gdb\Channelbelt_Kansas"
UniqueID = sys.argv[2]
path = sys.argv[3]
dsc = arcpy.Describe(ChannelBelt)
name = dsc.Name
if ".shp" in name:
    name = name.replace(".shp", "")

arcpy.env.overwriteOutput = True


arcpy.MakeFeatureLayer_management(ChannelBelt, name + "Route_layer")
arcpy.CreateRoutes_lr( name + "Route_layer",UniqueID,path +"//" + name +"_route.shp","LENGTH","#","#","UPPER_LEFT","1","0","IGNORE","INDEX")

arcpy.FeatureVerticesToPoints_management(path +"//" + name +"_route.shp",path + "//" + name +"_vertices", "ALL")

arcpy.MakeFeatureLayer_management(path + "//" + name +"_vertices.shp", name + "_V_Layer")
arcpy.MakeFeatureLayer_management(path +"//" + name +"_route.shp", name + "_route_Layer")
arcpy.LocateFeaturesAlongRoutes_lr( name + "_V_Layer",name + "_route_Layer",UniqueID,"0 Meters",path +"//" + name +"_loc.dbf","RID POINT MEAS","FIRST","DISTANCE","ZERO","FIELDS","M_DIRECTON")

arcpy.AddField_management(path +"//" + name +"_loc.dbf", "Offset", "Long", "15")
##if s == "L":
##    arcpy.CalculateField_management(path +"//cb_loc.dbf", "Offset", "-250")
##else:

Offsetvalue = 250
arcpy.CalculateField_management(path +"//" + name +"_loc.dbf", "Offset", str(Offsetvalue))

arcpy.MakeTableView_management(path +"//" + name +"_loc.dbf", name + "_loc_layer", "RID = " + "\"" + UniqueID + "\"")

arcpy.MakeRouteEventLayer_lr( name + "_route_Layer",UniqueID,name + "_loc_layer","rid POINT meas",name + "_loc_"+" Events","OFFSET","NO_ERROR_FIELD","NO_ANGLE_FIELD","NORMAL","ANGLE","RIGHT","POINT")

arcpy.PointsToLine_management(name + "_loc_"+" Events", path + "//" + name + "offset.shp",UniqueID,"MEAS","NO_CLOSE")

addlayertomap.main(path + "//" + name + "offset.shp")        