import arcpy
def main(sampdist):
	mxd = arcpy.mapping.MapDocument(r"C:\temp\fpztest\KansasTest\MedicineCreek.mxd")
	filepath = mxd.filePath
	if filepath:
		dsc = arcpy.Describe(filepath)
		basepath = dsc.path
		name = dsc.name
		try:
			txtfile = basepath + "\\" + name.replace(".mxd", "") + "_RESdatalayers.txt"
			f = open(txtfile)
			inputlist = f.readlines()
			sampdist = inputlist[10]
			print sampdist
		except:
			print "an exception"
	return sampdist