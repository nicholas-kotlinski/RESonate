import arcpy, sys, math, getsampdist
from math import sqrt, pow

def main(MasterTable, CBIntersect, SpatialJoin, Channelbelt, path):
    upStreamDict = {}
    rows = arcpy.SearchCursor(MasterTable)
    row = rows.next()
    arcpy.env.overwriteOutput = True

    while row:
        SegID = row.getValue("Seg_ID")
        UpSegID = row.getValue("Seg_ID_US")
        upStreamDict[SegID] = UpSegID
        row = rows.next()
    del row, rows

    LeftSinuCBDict = {}
    RightSinuCBDict = {}
    LeftStrCBDict = {}
    RightStrCBDict = {}

    rows = arcpy.SearchCursor(SpatialJoin, "Use = 'yes'")
    row = rows.next()
    while row:
        SegID = row.getValue("Seg_ID")
        Side = row.getValue("Side")
        Length = row.getValue("SHAPE_Length")
        if Side == "left":
            LeftStrCBDict[SegID] = Length
        elif Side == "right":
            RightStrCBDict[SegID] = Length
        row = rows.next()
    del row, rows


    
    cbLeftDistDict = {}
    cbRightDistDict = {}
    for id, upID in upStreamDict.iteritems():
        Query = "Min = 'yes' AND (Seg_ID ='" + id +"' OR Seg_ID = '" + upID + "')"
##        print Query


        sampdist = ""
        sampdist = getsampdist.main(sampdist)
        
        rows = arcpy.SearchCursor(CBIntersect, Query)
        row = rows.next()

        while row:
##            print upID
            SegID = row.getValue("Seg_ID")
##            print SegID
##            arcpy.AddMessage(SegID)
            side = row.getValue("side")
            x = row.getValue("Point_X")
            y = row.getValue("Point_Y")
            if SegID == id and side == "left" and upID <> "end":
                xL1 = x
                yL1 = y
            elif SegID == id and side == "right" and upID <> "end":
                xR1 = x
                yR1 = y
            elif SegID == upID and side == "left":
                xL2 = x
                yL2 = y
            elif SegID == upID and side == "right":
                xR2 = x
                yR2 = y
            elif upID == "end" and side  == "left":
                xL1 = x
                yL1 = y

                arcpy.MakeFeatureLayer_management(path+"//ChannelBelt//transect_intersect_singleCB_spatjoin","Channel Belt Intersect Pts Layer","Min = 'yes' AND Seg_ID = '" + SegID +"' And side = 'left'")
                print "Min = 'yes' AND Seg_ID = '" + SegID +"' And side = 'left'"
                arcpy.MakeFeatureLayer_management(path +"\\ChannelBelt\\cb_endpoints", "CB_endpoints")
             
                arcpy.SelectLayerByLocation_management("CB_endpoints","WITHIN_A_DISTANCE","Channel Belt Intersect Pts Layer",sampdist,"NEW_SELECTION")
                rowsE = arcpy.SearchCursor("CB_endpoints")
                rowE = rowsE.next()
                while rowE:
                    sideE = rowE.getValue("side")
##                    arcpy.AddMessage(sideE)
                    print sideE
                    if sideE =="L":
                        xL2 = rowE.getValue("Point_X")

                        print "xL2 = " + str(xL2)
                        yL2 = rowE.getValue("Point_Y")
                    rowE = rowsE.next()
                del rowsE, rowE
            elif upID == "end" and side  == "right":
                xR1 = x
                yR1 = y
                arcpy.MakeFeatureLayer_management(path+"//ChannelBelt//transect_intersect_singleCB_spatjoin","Channel Belt Intersect Pts Layer","Min = 'yes' AND Seg_ID = '" + SegID +"' And side = 'right'")
##                print "Min = 'yes' AND Seg_ID = '" + SegID +"' And side = 'right'"
                arcpy.MakeFeatureLayer_management(path +"\\ChannelBelt\\cb_endpoints", "CB_endpoints")
                arcpy.SelectLayerByLocation_management("CB_endpoints","WITHIN_A_DISTANCE","Channel Belt Intersect Pts Layer",sampdist,"NEW_SELECTION")
                rowsE = arcpy.SearchCursor("CB_endpoints")
                rowE = rowsE.next()
                while rowE:
                    sideE = rowE.getValue("side")
                    if sideE =="R":
                        xR2 = rowE.getValue("Point_X")
                        yR2 = rowE.getValue("Point_Y")
                    rowE = rowsE.next()
                del rowsE, rowE
            row = rows.next()



##            
        cbLeftDist = sqrt(pow((xL1 - xL2),2) + pow((yL1 - yL2),2))
        cbLeftDistDict[id] = cbLeftDist
        cbRightDist = sqrt(pow((xR1 - xR2),2) + pow((yR1 - yR2),2))
        cbRightDistDict[id] = cbRightDist
        print cbLeftDist
        print cbRightDist

    del row, rows

    rows = arcpy.UpdateCursor(MasterTable)
    row = rows.next()

    while row:
        SegID = row.getValue("Seg_ID")
        l = 0
        r = 0

        if SegID in LeftStrCBDict.keys():
            cbLeftStrDist = LeftStrCBDict[SegID]
            cbLeftDist = cbLeftDistDict[SegID]
            LeftSinu = cbLeftDist/cbLeftStrDist
            row.setValue("SinuLCB",LeftSinu)

            l = 1
            
        if SegID in RightStrCBDict.keys():
            cbRightStrDist = RightStrCBDict[SegID]
            cbRightDist = cbRightDistDict[SegID]
            RightSinu = cbRightDist/cbRightStrDist
            row.setValue("SinuRCB", RightSinu)

            r = 1
            
        if l == 0:
##            print "Left missing " + SegID
            row.setValue("SinuLCB", -999)
        if r == 0:
##            print "Right missing " + SegID
            row.setValue("SinuRCB", -999)
        rows.updateRow(row)
        row = rows.next()

    del row, rows

               
