import arcpy, sys, math
from math import sqrt, pow

def main(MasterTable, CBIntersect, SpatialJoin, Channelbelt):
    upStreamDict = {}
    rows = arcpy.SearchCursor(MasterTable)
    row = rows.next()

    while row:
        SegID = row.getValue("Seg_ID")
        UpSegID = row.getValue("Seg_ID_US")
        upStreamDict[SegID] = UpSegID
        row = rows.next()
    del row, rows

    LeftSinuCBDict = {}
    RightSinuCBDict = {}
    LeftStrCBDict = {}
    RightStrCBDict = {}

    rows = arcpy.SearchCursor(SpatialJoin, "Use = 'yes'")
    row = rows.next()
    while row:
        SegID = row.getValue("Seg_ID")
        Side = row.getValue("Side")
        Length = row.getValue("SHAPE_Length")
        if Side == "left":
            LeftStrCBDict[SegID] = Length
        elif Side == "right":
            RightStrCBDict[SegID] = Length
        row = rows.next()
    del row, rows

##    #Generate endpoints for the channelbelt so sinuosity can be generated for the end segments
##
##    arcpy.FeatureVerticesToPoints_management("Channelbelt_Kansas_250offset","C:/temp/fpztest/KansasTest/MedicineCreek.gdb/cb_endpoints","BOTH_ENDS")

    cbLeftDistDict = {}
    cbRightDistDict = {}
    for id, upID in upStreamDict.iteritems():
        Query = "Min = 'yes' AND (Seg_ID ='" + id +"' OR Seg_ID = '" + upID + "')"
##        arcpy.AddMessage(Query)
       # print Query

        rows = arcpy.SearchCursor(CBIntersect, Query)
        row = rows.next()
        if upID == "end":
            LeftSinuCBDict[id] = -999
            RightSinuCBDict[id] = -999
        else:
            while row:
                SegID = row.getValue("Seg_ID")
                side = row.getValue("side")
                x = row.getValue("Point_X")
                y = row.getValue("Point_Y")
                if SegID == id and side == "left":
                    xL1 = x
                    yL1 = y
                elif SegID == id and side == "right":
                    xR1 = x
                    yR1 = y
                elif SegID == upID and side == "left":
                    xL2 = x
                    yL2 = y
                elif SegID == upID and side == "right":
                    xR2 = x
                    yR2 = y
                row = rows.next()
            
            cbLeftDist = sqrt(pow((xL1 - xL2),2) + pow((yL1 - yL2),2))
            cbLeftDistDict[id] = cbLeftDist
            cbRightDist = sqrt(pow((xR1 - xR2),2) + pow((yR1 - yR2),2))
            cbRightDistDict[id] = cbRightDist
    del row, rows

    rows = arcpy.UpdateCursor(MasterTable)
    row = rows.next()

    while row:
        SegID = row.getValue("Seg_ID")
        l = 0
        r = 0

        if SegID in LeftStrCBDict.keys():
            cbLeftStrDist = LeftStrCBDict[SegID]
            cbLeftDist = cbLeftDistDict[SegID]
            LeftSinu = cbLeftDist/cbLeftStrDist
            row.setValue("SinuLCB",LeftSinu)

            l = 1
            
        if SegID in RightStrCBDict.keys():
            cbRightStrDist = RightStrCBDict[SegID]
            cbRightDist = cbRightDistDict[SegID]
            RightSinu = cbRightDist/cbRightStrDist
            row.setValue("SinuRCB", RightSinu)

            r = 1
            
        if l == 0:
            row.setValue("SinuLCB", -999)
        if r == 0:
            row.setValue("SinuRCB", -999)
        rows.updateRow(row)
        row = rows.next()

    del row, rows

                
                
