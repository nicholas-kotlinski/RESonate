import arcpy, sys, math, CB_Sinuosity
arcpy.env.overwriteOutput = True
##MasterTable = sys.argv[1]

HydroLayer = sys.argv[1]
path = sys.argv[2]
ChannelBelt = sys.argv[3]
dsc = arcpy.Describe(HydroLayer)
ext = dsc.Extension

if ext == "shp":
    hydronamewext = dsc.Name
    hydroname = hydronamewext.rstrip("." + ext)
else:
    hydroname = dsc.Name
MasterTable = path + "\\" + hydroname + "_MasterTable"

CBIntersect = path + "\\ChannelBelt\\transect_intersect_singleCB_spatjoin"

#Check to make sure Channel Belt layer has "StreamName" field
fields = arcpy.ListFields(ChannelBelt)
fieldnamelist = []
for f in fields:
    f.name
    fieldnamelist.append(f.name)
if "StreamName" not in fieldnamelist:
    #arcpy.AddError("ERROR! StreamName field is missing please add a field called StreamName to channel belt offset layer")
    sys.exit("ERROR! StreamName field is missing please add a field called StreamName to channel belt offset layer")

ListofStreamNames = []
rows = arcpy.SearchCursor(MasterTable)
row = rows.next()
while row:
    name = row.getValue("StreamName")
    if name not in ListofStreamNames:
        ListofStreamNames.append(name)
    row = rows.next()
del row, rows
x = 0
for s in ListofStreamNames:
    #Split Channelbelt line by CBIntersect points
    arcpy.MakeFeatureLayer_management(CBIntersect, "CBIntersectMin_Layer", "Min = 'yes' AND Seg_ID LIKE '" + s + "%'")
    #"Min" = 'yes' AND "Seg_ID" LIKE 'BigSandyCreek%'
    arcpy.SelectLayerByAttribute_management("CBIntersectMin_Layer", "SWITCH_SELECTION")
    arcpy.MakeFeatureLayer_management(ChannelBelt, "ChannelBelt_select_Layer", "StreamName LIKE '" + s + "%'")
    arcpy.SplitLineAtPoint_management("ChannelBelt_select_Layer","CBIntersectMin_Layer",path +"\\ChannelBelt//channelbeltsplit_"+ s,"50 Meters")
    if x == 0:
        arcpy.CopyFeatures_management(path +"//ChannelBelt//channelbeltsplit_"+ s, path +"//ChannelBelt//channelbeltsplit")
    else:
        arcpy.Append_management(path +"//ChannelBelt//channelbeltsplit_"+ s,path +"//ChannelBelt//channelbeltsplit","TEST", "None")
    x = x + 1

#Run Spatial Join to attribute split lines with Segment IDs
arcpy.MakeFeatureLayer_management(CBIntersect, "CBIntersectMin_Layer", "Min = 'yes'")
arcpy.SpatialJoin_analysis(path + "//ChannelBelt/channelbeltsplit","CBIntersectMin_Layer",path +"//ChannelBelt/channelbeltsplit_spatjoin","JOIN_ONE_TO_MANY","KEEP_ALL","Side \"Side\" true true false 5 Text 0 0 ,First,#," + path + "//ChannelBelt/channelbeltsplit,Side,-1,-1;side \"side\" true true false 5 Text 0 0 ,First,#," + path + "//ChannelBelt/transect_intersect_singleCB,side,-1,-1;Seg_ID \"Segment ID\" true true false 50 Text 0 0 ,First,#," + path + "//ChannelBelt/transect_intersect_singleCB,Seg_ID,-1,-1;Min \"Min\" true true false 5 Text 0 0 ,First,#," + path + "//ChannelBelt/transect_intersect_singleCB,Min,-1,-1","INTERSECT","50 Meters","#")

upStreamDict = {}
rows = arcpy.SearchCursor(MasterTable)
row = rows.next()

while row:
    SegID = row.getValue("Seg_ID")
    UpSegID = row.getValue("Seg_ID_US")
    upStreamDict[SegID] = UpSegID
    row = rows.next()
del row, rows

SpatialJoin = path +"\\ChannelBelt\\channelbeltsplit_spatjoin"

#Generate endpoints for the channelbelt so sinuosity can be generated for the end segments
endpoints = path +"\\ChannelBelt\\cb_endpoints"
arcpy.FeatureVerticesToPoints_management(ChannelBelt, endpoints,"BOTH_ENDS")
arcpy.AddXY_management(path +"\\ChannelBelt\\cb_endpoints")

OIDList = []
sidelist = ["left", "right"]
for s in sidelist:
    for id, upID in upStreamDict.iteritems():
        rows = arcpy.SearchCursor(SpatialJoin, "Seg_ID = '" + id+ "' AND Min = 'yes' AND side = '" + s +"'")

        row = rows.next()

        while row:
            OID = row.getValue("OBJECTID")
            arcpy.MakeFeatureLayer_management(SpatialJoin, "SpatialJoin_Layer")
            arcpy.MakeFeatureLayer_management(CBIntersect, "CBIntersect_Layer")
            arcpy.MakeFeatureLayer_management(endpoints, "Endpoints_Layer")
            arcpy.SelectLayerByAttribute_management("SpatialJoin_Layer", "NEW_SELECTION", "ObjectID = " + str(OID))
            arcpy.SelectLayerByAttribute_management("CBIntersect_Layer", "NEW_SELECTION", "Seg_ID = '" + upID + "' AND side ='" + s +"' AND Min = 'yes'")

            if upID == "end":
                arcpy.SelectLayerByLocation_management("Endpoints_Layer","INTERSECT","SpatialJoin_Layer","#","NEW_SELECTION")
                count = arcpy.GetCount_management("Endpoints_Layer")
            else:
                arcpy.SelectLayerByLocation_management("CBIntersect_Layer","INTERSECT","SpatialJoin_Layer","#","SUBSET_SELECTION")
                count = arcpy.GetCount_management("CBIntersect_Layer")
            count = int(str(count))
            if count == 1:
                OIDList.append(OID)
            row = rows.next()
        del row, rows
    arcpy.AddMessage(s + " side is complete")
    print s + " side is complete"

arcpy.AddField_management(SpatialJoin, "Use", "Text", "", "", "5")

rows = arcpy.UpdateCursor(SpatialJoin)
row = rows.next()


while row:
    OID = row.getValue("OBJECTID")
    if OID in OIDList:
        row.setValue("Use", "yes")
        rows.updateRow(row)
    row = rows.next()
del row, rows
# Call Channel Belt Sinuosity Script
print "Calculating Channel Belt Sinuosity"
CB_Sinuosity.main(MasterTable, CBIntersect, SpatialJoin, ChannelBelt, path)
mxd = arcpy.mapping.MapDocument("Current")
mxd.save()
            
               