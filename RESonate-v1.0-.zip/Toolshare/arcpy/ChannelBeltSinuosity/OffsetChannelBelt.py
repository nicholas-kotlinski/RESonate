import arcpy, sys, addlayertomap
arcpy.env.overwriteOutput = True

ChannelBelt = sys.argv[1]
dsc = arcpy.Describe(ChannelBelt)
filename = dsc.File

if ".shp" in ChannelBelt:
    name = filename.replace(".shp", "")
else:
    name = ChannelBelt
    
UniqueID = sys.argv[2]
path = sys.argv[3]
pdsc = arcpy.Describe(path)
datatype = pdsc.DataType

offset = sys.argv[4]

SideList = ("R", "L")
for s in SideList:
    arcpy.MakeFeatureLayer_management(ChannelBelt, "ChannelBeltRoute_layer", "Side = '" + s + "'")
    if datatype == "Folder":
        routename = path +"\\" + name + "_route_" + s + ".shp"
    elif datatype == "FeatureDataset":
        routename = path +"\\" + name + "_route_" + s
        
    arcpy.CreateRoutes_lr("ChannelBeltRoute_layer",UniqueID,routename,"LENGTH","#","#","LOWER_LEFT","1","0","IGNORE","INDEX")
    
    arcpy.FeatureVerticesToPoints_management(routename, path + "//" + name +"_vertices_" + s, "ALL")
    
    if datatype == "Folder":
        vname = path + "//" + name +"_vertices_" + s + ".shp"
    elif datatype == "FeatureDataset":
        vname = path + "//" + name +"_vertices_" + s

    if datatype == "Folder":
        loctable = path +"//"+ name+"_loc_" + s + ".dbf"
    elif datatype == "FeatureDataset":
        bpath = pdsc.Path
        loctable = bpath +"//"+ name+"_loc_" + s 
        
    arcpy.MakeFeatureLayer_management(vname, name + "_V_Layer_" + s)
    arcpy.MakeFeatureLayer_management(routename, name +"_route_" + s + "_Layer")
    arcpy.LocateFeaturesAlongRoutes_lr( name + "_V_Layer_" + s, name +"_route_" + s + "_Layer",UniqueID,"0 Meters",loctable,"RID POINT MEAS","FIRST","DISTANCE","ZERO","FIELDS","M_DIRECTON")

    arcpy.AddField_management(loctable, "Offset", "Long", "15")
    if s == "R":
        arcpy.CalculateField_management(loctable, "Offset", "-"+ offset)
    else:
        arcpy.CalculateField_management(loctable, "Offset", offset)

   # arcpy.MakeFeatureLayer_management(path +"//CB_route_" + s +".shp", "CB_route_" + s + "_layer")
    arcpy.MakeTableView_management(loctable, name +"_loc_" + s + "_layer", "RID = " + "\"" + UniqueID + "\"")
  
    arcpy.MakeRouteEventLayer_lr(name +"_route_" + s + "_Layer",UniqueID,name +"_loc_" + s + "_layer","rid POINT meas",name + "_loc_" + s +" Events","OFFSET","NO_ERROR_FIELD","NO_ANGLE_FIELD","NORMAL","ANGLE","RIGHT","POINT")

    if datatype == "Folder":
        pttoline = path + "//"+ name+ "loc_pttoline_" + s + ".shp"
    elif datatype == "FeatureDataset":
        pttoline = path + "//"+ name+ "loc_pttoline_" + s
  
    arcpy.PointsToLine_management(name +"_loc_" + s +" Events", pttoline,UniqueID,"MEAS","NO_CLOSE")
    arcpy.AddField_management(pttoline, "Side", "Text", "", "", "5")
    arcpy.CalculateField_management(pttoline, "Side", "\"" + s + "\"")

if datatype == "Folder":
    Rpttoline = path + "//" + name + "loc_pttoline_R.shp"
elif datatype == "FeatureDataset":
    Rpttoline = path + "//" + name + "loc_pttoline_R"

if datatype == "Folder":
    Lpttoline = path + "//" + name + "loc_pttoline_L.shp"
elif datatype == "FeatureDataset":
    Lpttoline = path + "//" + name + "loc_pttoline_L"

if datatype == "Folder":
    offsetlayer = path + "//" + name +"_"+ offset +"offset.shp"
elif datatype == "FeatureDataset":
    offsetlayer = path + "//" + name +"_"+ offset +"offset"    
arcpy.CopyFeatures_management(Rpttoline, offsetlayer)
arcpy.Append_management(Lpttoline,  offsetlayer, "TEST", "", "")
addlayertomap.main(offsetlayer)

            