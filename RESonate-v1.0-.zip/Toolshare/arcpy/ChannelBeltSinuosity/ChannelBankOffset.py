import arcpy
arcpy.env.overwriteOutput = True

ChannelBelt = r"C:\temp\fpztest\cbtest\ChannelBelt_Test2.shp"
RightOffset = r"C:\temp\fpztest\cbtest\KansasCBTest2.gdb\ChannelBelt\ChannelBelt_offset225_rt_line_spltv"
LeftOffset =  r"C:\temp\fpztest\cbtest\KansasCBTest2.gdb\ChannelBelt\ChannelBelt_offset225_lft_line_spltv"

SideList = ["R", "L"]
for s in SideList:
    rows = arcpy.SearchCursor(ChannelBelt, "Side = '" + s +"'")
    row = rows.next()

    while row:
        RiverName = row.getValue("RiverName")
        arcpy.MakeFeatureLayer_management(ChannelBelt, "ChannelBelt_Layer")
        arcpy.SelectLayerByAttribute_management("ChannelBelt_Layer", "NEW_SELECTION", "RiverName = '" + RiverName + "' AND Side = '" + s + "'")
        if s == "R":
            InputLayer = RightOffset
        elif s == "L":
            InputLayer = LeftOffset
        arcpy.MakeFeatureLayer_management(InputLayer, "Offset_Layer")
        arcpy.SelectLayerByLocation_management("Offset_Layer","Intersect","ChannelBelt_Layer","","NEW_SELECTION")

        rowsU = arcpy.UpdateCursor("Offset_Layer")
        rowU = rowsU.next()
        while rowU:
            rowU.setValue("Remove", "yes")
            rowsU.updateRow(rowU)
            rowU = rowsU.next()
        del rowU, rowsU
        
        arcpy.SelectLayerByAttribute_management("Offset_Layer", "SWITCH_SELECTION")
        rowsU = arcpy.UpdateCursor("Offset_Layer")
        rowU = rowsU.next()
        while rowU:
            rowU.setValue("RiverName", RiverName)
            rowsU.updateRow(rowU)
            rowU = rowsU.next()
        del rowU, rowsU
        
        row = rows.next()
        
                                               