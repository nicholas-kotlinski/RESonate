import os, arcpy, sys

def main (basepath, name, sitelocjoin, GeolField):
    mastertable = basepath +"\\" + name +"_MasterTable"
    dscSJ = arcpy.Describe(sitelocjoin)
    SJlayerwpath = dscSJ.CatalogPath

    dscMT = arcpy.Describe(mastertable)
    MTwpath = dscMT.CatalogPath

    rows = arcpy.SearchCursor(SJlayerwpath)
    row = rows.next()

    while row:
        Seg_ID = row.getValue("Seg_ID")
        print Seg_ID
        Precip = row.getValue("MeanAnnPrecip")
        Elev = row.getValue("Elev")
        Geol = row.getValue(GeolField)
        rowsM = arcpy.UpdateCursor(MTwpath)
        rowM = rowsM.next()
        while rowM:
            Seg_ID_M = rowM.getValue("Seg_ID")
            print "Master:" +Seg_ID_M
            if Seg_ID == Seg_ID_M:
                rowM.setValue("MeanAnnPrecip", Precip)
                rowM.setValue("Elev", Elev)
                rowM.setValue("Geology", Geol)
                rowsM.updateRow(rowM)
                break
            rowM = rowsM.next()
        row = rows.next()
                
                            
        