#Get input layers for Resonate calculations
#Created on Jan 25 2010, updated October 14, 2011, May 10 2012
#Sets up input layers.  Records the inputs to a text file saved in the same location as the file geodatabase.

# Import system modules
import sys, string, os, arcpy, addlayertomap, addfield, createfilegdb, CalcGeolElevPrecip, Slope
# Check to see if mxd is saved, if it is not then the program will NOT continue
mxd = arcpy.mapping.MapDocument("Current")
filepath = mxd.filePath

if filepath:
    #get mxd name
    dscmxd = arcpy.Describe(filepath)
    mxdname = dscmxd.name
    mxdrootname = mxdname.replace(".mxd", "")

    x = 0


    #script arguments
    #get path where the file geodatabase will be saved
##    projectpath = sys.argv[1]

    #Get Hydrology Layer
    hydrolayer = sys.argv[1]
    dsc = arcpy.Describe(hydrolayer)

    #Get the name of the Hydrology Layer.
    if ":" in hydrolayer:
        thefilepath = hydrolayer
        path,fi = os.path.split(thefilepath)
        name, ext = fi.split(".")

    else:
        name = dsc.namestring

    #Get DEM Layer
    DEMlayer = sys.argv[2]

    #Get Precipitation Layer
    PrecipLayer = sys.argv[3]

    #Get Geology Layer and field
    GeolLayer = sys.argv[4]
    GeolField = sys.argv[5]

    #Get Floodplain Layer
    FloodLayer = sys.argv[6]

    #Get Microshed Layer
    MicroshedLayer = sys.argv[7]

    #Get Channel Belt Layer
    CBLayer = sys.argv[9]
    CBOffsetvalue = sys.argv[10]

    #Get Sampling Distance
    SampleDistance = sys.argv[8]

    sitelocations = ""
##    #Check to see that the Floodplain and Geology Layers are polygons
##    layers = [GeolLayer, FloodLayer]
##    for l in layers:
##        dsc = arcpy.Describe(l)
##        stype = dsc.shapetype
##        if stype <> "Polygon":
##            if l == GeolLayer:
##                msg = "Error - Geology Layer MUST be a polygon"
##                arcpy.AddError(msg)
##            if l == FloodLayer:
##                msg = "Error - Flood Layer MUST be a polygon"
##                arcpy.AddError(msg)
##        #set x = 1 to indicate an error occured
##            x = 1
##            
##    #Check to see that the Microshed layer is a line
##    layers = [MicroshedLayer, hydrolayer]
##    for l in layers:
##        dscL = arcpy.Describe(l)
##        stype = dscL.shapetype
##        if stype <> "Polyline":
##            if l == MicroshedLayer:
##              msg = "Error - Microshed Layer MUST be a polyline"
##              arcpy.AddError(msg)
##            if l == hydrolayer:
##              msg = "Error - Hydrology Layer MUST be a polyline"
##              arcpy.AddError(msg)
##            #set x = 1 to indicate an error occured
##            x = 1
##
##    if x == 1:
##       sys.exit()

    #Create a new text file to record inputs
    dscfp = arcpy.Describe(filepath)
    filebasepath = dscfp.path
    fout = open(filebasepath + "\\"+ mxdrootname +"_RESdatalayers.txt", 'w')
    fout.write(filebasepath + "\n")

    #Check to see if the Channelbank input is blank.  If blank then do not add it to layer list.
    if CBLayer == "#":
        layerlist = [hydrolayer, DEMlayer, PrecipLayer,GeolLayer, FloodLayer, MicroshedLayer]
        #layerlist = [hydrolayer,GeolLayer, FloodLayer, MicroshedLayer]
    else:
        layerlist = [hydrolayer, DEMlayer, PrecipLayer, GeolLayer, FloodLayer, MicroshedLayer,CBLayer]
        
    #Check to see if the path is included in the datalayer name.  If it is then the path is removed.

    countpaths = 0
    for l in layerlist:
        if ":" in l:
         thefilepath = l
         path,fi = os.path.split(thefilepath)
         if "." in fi:
            strname, ext = fi.split(".")
            fout.write (strname + "\n")
         else:
            fout.write(fi + "\n")
        else:
         dsc = arcpy.Describe(l)
         strname = dsc.namestring
         fout.write (strname + "\n")

    #Check to see if the channel bank is blank
    if CBLayer == "#":
        fout.write("Channel bank is blank" + "\n")
        fout.write("Channel bank offset: N/A" + "\n")
    else:
        fout.write(CBOffsetvalue + "\n")

    SampleDistanceText = str(SampleDistance)
    fout.write(GeolField + "\n")
    fout.write(SampleDistanceText + "\n")
    fout.close

    #Check to see if the hydrology layer is projected
    dsc = arcpy.Describe(hydrolayer)
    spatref = dsc.SpatialReference
    if spatref.type == "Projected":
        units =spatref.linearunitname
        arcpy.AddMessage ("Your data is in " + units)

    else:
        arcpy.AddError("ATTENTION Your hydrology layer is NOT projected!")
        arcpy.AddError("It must be projected to continue!")
        x ==1
        
    if x == 1:
       sys.exit()
        

    #Add layers to map if not already added     
    if CBLayer == "#":
        shapelist = [hydrolayer, GeolLayer, FloodLayer, MicroshedLayer]
    else:
        shapelist = [hydrolayer, GeolLayer, FloodLayer, MicroshedLayer, CBLayer]

    countpaths = 0    
    for l in shapelist:
        if ":" in l:
         countpaths = countpaths + 1
         addlayertomap.main(l)

    rasterlist = [DEMlayer, PrecipLayer]
    rastcount = 0
    for r in rasterlist:
        if ":" in l:
         rastcount = rastcount + 1
         addlayertomap.main(r)
         
    #Check to see if LengthKM and StreamName exist in the hydrography layer
    l= ""
    s= ""
    fields = arcpy.ListFields(sys.argv[1])
    for field in fields:
        a = field.name
        #arcpy.addmessage(a)
        if a == "LengthKM":
         msg = "LengthKM Found"
         l = "lengthfound"
         arcpy.AddMessage(msg)
        if a == "StreamName":
         msg = "StreamName Found"
         s = "streamfound"    
         arcpy.AddMessage(msg)

    if l =="":
        msg = "WARNING LENGTHKM NOT FOUND!!!"
        arcpy.AddWarning(msg)
        field = "LengthKM"
        addfield.main(hydrolayer, field, units)

            
    if s =="":
        msg = "WARNING STREAMNAME NOT FOUND!!!"
        field = "StreamName"
        arcpy.AddWarning(msg)
        addfield.main(hydrolayer, field, units)

    sitelocations = createfilegdb.main(filebasepath, hydrolayer, spatref, SampleDistance, sitelocations)

    dscG = arcpy.Describe(GeolLayer)
    Geowpath = dscG.CatalogPath

    basepath = filebasepath + "\\"+ name + ".gdb\\"


    #Calculte Geology, Elev, and Precipitation
    CalcGeolElevPrecip.main(sitelocations, DEMlayer, PrecipLayer, Geowpath, basepath, GeolField, name)
    arcpy.AddMessage("Geology, Elevation, and Precipitation have been added to Master table")


    #Calculate Slope
    Slope.main(name, hydrolayer, DEMlayer, basepath, sitelocations, SampleDistance, units)

    #Delete Extra Fields in Sitelocation attribute table
    arcpy.DeleteField_management(sitelocations,"MeanAnnPrecip;Geology;Elev;ValWidth;ValFlrWidth;RatioVWtoFW;LftVSl;RtVSl;DownVSl;SineLCB;SineRCB;CBWidth;SineRC;Planform;Distance;ORIG_FID;POINT_M")
    mxd.save()
else:
    arcpy.AddError("Project MUST be saved before continuing!!")

