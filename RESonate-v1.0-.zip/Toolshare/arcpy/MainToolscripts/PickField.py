import Tkinter as tk, arcpy, sys, os, calcfields

def main(argv, fname):
                      
   # def add_item():

   # add the text in the Entry widget to the end of the listbox

    def get_list(event):
    #function to read the listbox selection and put the result in an entry widget
    #get selected line index
        index = listbox1.curselection()[0]
    #get the line's text
        seltext = listbox1.get(index)
    #delete previous text in enter1
        enter1.delete(0,50)
    #now display the selected text
        enter1.insert(0, seltext)

    def printselection():
	#get selected line index
        index = listbox1.curselection()[0]
    #get the line's text
        seltext = listbox1.get(index)
        seltext =listbox1.get(index)
        #print seltext
        arcpy.AddMessage(seltext)
        #gp.addmessage(argv)
        root.destroy()
        calcfields.main(seltext, argv, fname)
              
# create the sample list

    def set_list(event):
    #Insert an edited line from the entry widget back into the listbox
        try:
            index = listbox1.curselection()[0]
            listbox1.delete(index)
        except IndexError:
            index = tk.END
   
    root= tk.Tk()
    if fname == "stream":
        titlename = "Select Stream Field"
    elif fname == "lengthkm":
        titlename = "Select Length Field"
    root.title(titlename)
#create the listbox (note that size is in characters)
    listbox1 = tk.Listbox(root, width = 40, height = 6)
    listbox1.grid (row=0, column =0)

#create a vertical scrollbar to the right of the listbox
    yscroll = tk.Scrollbar(command = listbox1.yview, orient = tk.VERTICAL)
    yscroll.grid(row = 0, column = 1, sticky = tk.N+tk.S)
    listbox1.configure(yscrollcommand=yscroll.set)


#button to sort listbox
    button1 = tk.Button(root, text= 'Enter', command= printselection)
    button1.grid(row=3, column=0, sticky=tk.EW)

    #hydrolayer = sys.argv[1]
    hydrolayer = argv
    #fields = gp.listFields(sys.argv[1])
    fields = arcpy.ListFields(argv)
    for field in fields:
     a = field.name
     listbox1.insert(tk.END, a)

#load the listbox with data
    def loaditems():
        hydrolayer = argv
        fields = arcpy.ListFields(argv)
        for item in fields:
         a = field.name
         arcpy.AddMessage(a)
         listbox1.insert(tk.END, a)

#left mouse click on a list item to display selection
    listbox1.bind('<ButtonRelease -1>', get_list)
    

    root.mainloop()
    

