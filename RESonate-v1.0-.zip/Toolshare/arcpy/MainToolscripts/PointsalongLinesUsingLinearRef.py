# ---------------------------------------------------------------------------
# PointsalongLinesUsingLinearRef2.py
# Created on: Fri Sep 10 2010 03:57:54 PM
# Usage: PointsalongLinesUsingLinearRef2 
# ---------------------------------------------------------------------------

# Import system modules
import sys, string, os, arcpy, addlayertomap

def main (name,mastertablename, path, sitelocations):
    sitelocations = path + "\\sitelocations"
    arcpy.MakeTableView_management(mastertablename, name + "_MasterTable", "", "", "Seg_ID Seg_ID VISIBLE NONE;Units Units VISIBLE NONE;MeanAnnPreciip MeanAnnPreciip VISIBLE NONE;Geology Geology VISIBLE NONE;Elev Elev VISIBLE NONE;ValWidth ValWidth VISIBLE NONE;ValFlrWidth ValFlrWidth VISIBLE NONE;RatioVWtoFW RatioVWtoFW VISIBLE NONE;LftVSl LftVSl VISIBLE NONE;RtVSl RtVSl VISIBLE NONE;DownVSl DownVSl VISIBLE NONE;SineLCB SineLCB VISIBLE NONE;SineRCB SineRCB VISIBLE NONE;CBWidth CBWidth VISIBLE NONE;SineRC SineRC VISIBLE NONE;Planform Planform VISIBLE NONE;Distance Distance VISIBLE NONE;StreamName StreamName VISIBLE NONE")
    # Process: Make Route Event Layer...
    arcpy.MakeRouteEventLayer_lr(name, "StreamName", mastertablename, "StreamName POINT Distance", name +"_MasterTable" + "_Events", "", "NO_ERROR_FIELD", "NO_ANGLE_FIELD", "NORMAL", "ANGLE", "LEFT", "POINT")
    arcpy.SetParameterAsText(10, name +"_MasterTable")
    
    # Convert Event Layer to point
    arcpy.FeatureToPoint_management(name +"_MasterTable" + "_Events", sitelocations, "CENTROID")

    #Add xy coordinates to Output
    arcpy.AddXY_management(sitelocations)
   # arcpy.AddMessage("AddXY_management complete")
    addlayertomap.main(sitelocations)
 
    arcpy.AddMessage ("Finished Linear Referencing")
    return sitelocations
