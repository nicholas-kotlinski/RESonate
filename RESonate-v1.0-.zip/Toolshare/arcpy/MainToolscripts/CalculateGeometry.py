import sys, string, os, arcpy

def main(intable, units):
    rows =arcpy.SearchCursor(intable)

    row = rows.next()
    # Calculate the total length of all roads

    rowsU = arcpy.UpdateCursor(intable)
    rowU = rowsU.next()
    while row:
        feat = row.shape
        length = feat.Length
        #Check the units
        if units == "Meter":
         rowU.LengthKM = length/1000
        else:
         rowU.LengthKM = (length*0.3048)/1000
        rowsU.UpdateRow(rowU)
        row = rows.next()
        rowU = rowsU.next()


    del row, rows, rowsU, rowU    