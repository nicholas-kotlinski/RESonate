# Import system modules
import sys, string, os, arcpy

def main (field, argv, fname):

    arcpy.AddMessage("The selected field is: " + field)
    arcpy.AddMessage(argv)
    arcpy.AddMessage("The selected field is: " + argv)

#Get units from Hydrology layer
    dsc = arcpy.Describe(argv)
    spatref = dsc.SpatialReference
    units = spatref.linearunitname

    arcpy.AddMessage("Your data is in " + units + ". It will be converted to km")   
    if fname == "stream":
     #gp.CalculateField_management(argv, "StreamName", "["+field + "]", "VB", "")
     arcpy.CalculateField_management(argv, "StreamName", "replace(["+field + "],\" \", \"\")", "VB", "")
     arcpy.CalculateField_management(argv, "StreamName", "replace( [StreamName] ,\"(\", \"_\")", "VB", "")
     arcpy.CalculateField_management(argv, "StreamName", "replace( [StreamName] ,\")\", \"\")", "VB", "")
     arcpy.AddMessage("StreamName field has been updated")
    elif fname == "lengthkm":
     if units == "Meter":
      arcpy.CalculateField_management(argv, "LengthKM", "["+field + "]/1000", "VB", "")
      arcpy.AddMessage("LengthKM field has been updated")
     elif units == "Foot_US" or units == "Foot":
      arcpy.CalculateField_management(argv, "LengthKM", "["+field + "]*0.0003048 ", "VB", "") 
      arcpy.AddMessage("LengthKM field has been updated")
    