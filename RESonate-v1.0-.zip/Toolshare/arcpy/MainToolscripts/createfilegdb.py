# ---------------------------------------------------------------------------
# createfilegdb.py
# Created on: Fri Feb 05 2010 12:37:52 PM
# Creates the file geodatabase that will store the data variables for the FPZs. Sets up the Master Table
# ---------------------------------------------------------------------------

# Import system modules
import sys, string, os, arcpy, AddFieldstoMaster, MakeTempTable, Addrowsandappend, PointsalongLinesUsingLinearRef

def main(fileLoc, name, spatref, SampleDistance, sitelocations):
    sitelocations = ""

# Local variables...
    File_GDB_Location = fileLoc
    
    if ":" in name:
     path,fi = os.path.split(name)
     name2, ext = fi.split(".")
    #createfeaturelayer.main(hydrolayer)
    else:
     name2 = name
    File_GDB_Name = name2 
    arcpy.AddMessage("The filegeodatabase will be called: " + File_GDB_Name )
# Process: Create File GDB...
    arcpy.CreateFileGDB_management(File_GDB_Location, File_GDB_Name)

# Process: Create Feature Dataset...
    FGDBwPath =fileLoc + "\\" + File_GDB_Name + ".gdb"
    FDatasetList = ["RiverS", "Transects", "ValleyFloorWidth", "ValleyWidth", "ChannelBelt"]
    for fdataset in FDatasetList:
        arcpy.CreateFeatureDataset_management(FGDBwPath, fdataset, spatref)
        
    AddFieldstoMaster.main(FGDBwPath, name2)

#Process:   Set up Temp Table to append to MasterTable
    MakeTempTable.main(FGDBwPath)
#Process: Add rows for each stream in hydrolayer to MasterTable. . .
    inTable = name
    StreamField = "StreamName"
    LengthField = "Lengthkm"
    rows = arcpy.SearchCursor(inTable)
    row = rows.next()

    arcpy.AddMessage("Adding rows for rivers segments")
    while row:
        sname = row.getValue(StreamField)
        length = row.getValue(LengthField)
        samplediststr = str(SampleDistance)
        sdiststr, sunit = samplediststr.split(" ")
        sdistance = sdiststr

        if sunit == "Kilometers":
         sdistance == float(sdistance)
        #This portion not working.
        elif sunit == "Meters":
         sdistance2 = float(sdistance)*0.001
         sdistance = sdistance2
        # arcpy.AddMessage("The sampling units are " + str(sdistance2) + " kilometers")
        elif sunit == "Feet":
         sdistance = float(sdistance)*0.0003048

        if float(length) < float(sdistance):
            arcpy.AddWarning (sname + " is less then sampling distance")
##            sys.exit()
        else:
            #MakeEventTables.main(FGDBwPath, sname, sdistance, sunit)
            numrows = float(length)/float(sdistance)
            numrows = int(numrows)
           # arcpy.AddMessage("Num rows for " + sname + " is: " + str(numrows))

            #Add an additional row to account for the 0 position
            numrows = numrows + 1
            
            #gp.addmessage(sname + " will have " + str(numrows) + " rows")
            snamewpath = FGDBwPath + "//TempTable"

            mastertablename = FGDBwPath + "//" + name2 + "_MasterTable"
            if sunit == "Meters":
                sdistance2 = float(sdistance)/0.001
                sdistance = sdistance2
            elif sunit == "Feet":
                sdistance = float(sdistance)*0.0003048
                

            Addrowsandappend.main(snamewpath, numrows, sname, sdistance, sunit, mastertablename)

        row = rows.next()
    arcpy.AddMessage ("Finished adding rows to Master. . . moving on to Linear Referencing")  
    sitelocations = PointsalongLinesUsingLinearRef.main(name2, mastertablename, FGDBwPath, sitelocations)
    #PointsalongLinesUsingLinearRef.main(name2, mastertablename, FGDBwPath, sitelocations)
    return sitelocations