#Sets up Temp Table that will be used to add rows to Master Table
# Import system modules
import sys, string, os, arcpy

def main(FGDBwPath):

# Process: Create the empty table
    arcpy.CreateTable_management(FGDBwPath, "TempTable")

    table = FGDBwPath + "//" + "TempTable"
    #Add Required Fields to Table
    arcpy.AddField_management(table, "StreamName", "TEXT", "","","50", "Stream Name", "NULLABLE", "NON_REQUIRED", "")
        
    NumFieldList = ['LengthKM', 'Distance', 'X_Coord', 'Y_Coord']
    AliasNumFieldList = ['Length KM', 'Distance', 'X Coordinate', 'Y Coordinate']
    for f,a in zip(NumFieldList, AliasNumFieldList):
        arcpy.AddField_management(table, f, "DOUBLE", "15", "8", "", a, "NULLABLE", "NON_REQUIRED", "")

    StrFieldList = ['Seg_ID', 'Units', 'Seg_ID_DS', 'Seg_ID_US']
    AliasStrFieldList = ['SegmentID', 'Units', 'Downstream Segment ID', 'Upstream Segment ID']
    for s, sa in zip(StrFieldList, AliasStrFieldList):
        arcpy.AddField_management(table, s, "TEXT", "", "", "50", sa, "NULLABLE", "NON_REQUIRED", "")
        
            