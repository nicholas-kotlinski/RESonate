import sys, os, arcpy, math
from math import sqrt, pow
from arcpy import env
def main(name, hydrolayer, dem, path, sitelocation, SampleDistance, units):
    env.overwriteOutput = True
    # Check out any necessary licenses
    arcpy.CheckOutExtension("3D")

    MasterTable = path + "\\" + name + "_MasterTable"
    distnum, distunit = SampleDistance.split(" ")
    distunit = distunit.replace("s", "")
    if distunit == units:
        dist = distnum
    else:
        if units == "Meter" and distunit == "Kilometer":
            dist = float(distnum) * 1000
        elif units == "Feet" and distunit == "Kilometer":
            dist = float(distnum)  * 3280.839895
        elif units == "Feet" and distunit == "Meter":
            dist = float(distnum)  * 3.280839895
        elif units == "Meter" and disunit == "Feet":
            dist = float(distnum)  * 0.3048
        else:
           arcpy.AddError ("Error your data is projected in something other than feet or meters - Slope was not calculated")

##    arcpy.AddMessage("Dist has been determined:" + str(dist))
    print "Dist has been determined:" + str(dist)
    dsc = arcpy.Describe(MasterTable)
    layerwpath = dsc.CatalogPath
    rows = arcpy.SearchCursor(MasterTable)
    row = rows.next()
    #Set up dictionary associating Segment ID with Elevation
    d = {}
    while row:
        Seg_ID = row.getValue("Seg_ID")
        Elev = row.getValue("Elev")
        d[Seg_ID] = Elev
        row = rows.next()
    del row, rows

    #Populate Slope to master table
    rows = arcpy.UpdateCursor(MasterTable)
    row = rows.next()

    while row:
        Seg_ID = row.getValue("Seg_ID")
        Seg_ID_US = row.getValue("Seg_ID_US")

        if Seg_ID_US <> "end":
            Start_Elev = d[Seg_ID]
            US_Elev = d[Seg_ID_US]
            Slope = (Start_Elev - US_Elev)/ float(dist)
            row.setValue("DownVSl", Slope)
            rows.updateRow(row)
        row = rows.next()
    del row, rows   
    #Convert hydroline to end points
    arcpy.FeatureVerticesToPoints_management (hydrolayer, path + "//Transects//endpoints", "BOTH_ENDS")

    #Add XY to endpoints
    arcpy.AddXY_management (path + "//Transects//endpoints")

    #Add Elevation for endpoints
    #gp.SurfaceSpot_3d(dem, path + "//Transects//endpoints", "Elev", "1", "BILINEAR")
    arcpy.AddSurfaceInformation_3d(path + "//Transects//endpoints",dem, "Z", "BILINEAR","#","1","0")
    arcpy.AddField_management(path + "//Transects//endpoints", "Elev", "DOUBLE", "15", "8")
    arcpy.CalculateField_management(path + "//Transects//endpoints","Elev","[Z]","VB","#")
    arcpy.DeleteField_management(path + "//Transects//endpoints","Z")
    
    #Find which point is the end point and use it to get the slope value for the last segment ids on a stream
    rows = arcpy.UpdateCursor(sitelocation)
    row = rows.next()
    count = 0

    dEnd= {}
    while row:
        Seg_ID = row.getValue("Seg_ID")
        Seg_ID_US = row.getValue("Seg_ID_US")
        if Seg_ID_US == "end":
            SegX = row.getValue("Point_X")
            SegY = row.getValue("Point_Y")
            river = row.getValue("StreamName")
            rowsE = arcpy.SearchCursor(path + "//Transects//endpoints")
            rowE= rowsE.next()
            while rowE:
                StreamName = rowE.getValue("StreamName")
                if StreamName == river:
                    UpX=rowE.getValue("Point_X")
                    UpY=rowE.getValue("Point_Y")
                    elev = rowE.getValue("Elev")
                    count = count + 1
                #    print count
                    if count == 1:
                        dist1 = sqrt(pow((SegX - UpX),2) + pow((SegY - UpY), 2))
                        elev1 = elev
                    else:
                        dist2 = sqrt(pow((SegX - UpX),2) + pow((SegY - UpY), 2))
                        elev2 = elev
                    if count == 2:
                        if dist1 < dist2:
                            US_Elev = elev1
                        elif dist2 < dist:
                            US_Elev = elev2
                        Start_Elev = d[Seg_ID]
                        Slope = (Start_Elev - US_Elev)/ float(dist)
                        dEnd[Seg_ID] = Slope
                        count = 0
                rowE = rowsE.next()
        row = rows.next()
    del row, rows, rowE, rowsE

    #Update End of line segments with Slope
    rows = arcpy.UpdateCursor(MasterTable)
    row = rows.next()               
    while row:
        Seg_ID = row.getValue("Seg_ID")
        Seg_ID_US = row.getValue("Seg_ID_US")
        if Seg_ID_US == "end":
            Slope = dEnd[Seg_ID]
            row.setValue("DownVSl", Slope)
            rows.updateRow(row)
        row = rows.next()
    arcpy.AddMessage ("Slope calculations are complete")


        