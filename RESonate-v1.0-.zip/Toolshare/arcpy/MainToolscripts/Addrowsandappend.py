import sys, string, os, arcpy
#Add rows to Temp table then appends the Temp table to the Master Table.  It also records the upstream and downstream Segment IDs.
def main(snamewpath, numrows, sname, sdistance, sunit, mastertablename):
    #arcpy.AddMessage ("Got to add rows and append")
    #Get ObjectID from InTable

    ObjectIDField = "OBJECTID"
    intable = snamewpath
    rows =arcpy.InsertCursor(intable)
    r = numrows

    while numrows <> 0:
         row = rows.newRow()
         rows.insertRow(row)
         numrows= numrows - 1  

     
    rows = arcpy.UpdateCursor(intable)
    row = rows.next()
    
    #arcpy.AddMessage("User distance is: " + str(userdistance))
   #arcpy.AddMessage("sdistance is: " + str(sdistance))
    
    if sunit == "Kilometers":
        #arcpy.AddMessage("The unit is " + sunit)
        if float(sdistance) < 1:
           # arcpy.AddMessage("Sdistance is less than one")
            userdistance = float(sdistance) * 1000
            sdistance = float(sdistance) * 1000
        else:
            userdistance = int(sdistance) * 1000
            sdistance = int(sdistance) * 1000
            
        sunit = "km"
    else:
        #arcpy.AddMessage("oops it found the wrong one")
        userdistance = float(sdistance)
        sunit = "m"
    x = 0
   # arcpy.AddMessage("userdistance is: " + str(userdistance))
    while row:
        objectid = row.getValue(ObjectIDField)
        #row.StreamName = sname
        row.setValue("StreamName", sname)
        row.setValue("Distance", x)
        row.setValue("Units", sunit)
        #if float(sdistance) < 1:
        ds = float(x - sdistance)
        #arcpy.AddMessage("Downstream: " + str(ds))                       
        us = float(x + sdistance)
       # arcpy.AddMessage("Upstream: " + str(ds))  
        x = float(x)
##        else:
##            ds = int(x - sdistance)
##            us = int(x + sdistance)
##            x = int(x)
       # arcpy.AddMessage("ds = " + str(ds) + ", us = " + str(us) + ", x = " + str(x))
        if sunit == "km":
##            arcpy.AddMessage("sunit is: " + sunit)
            segid = sname + "_" + str((float(x)/1000))+ sunit
            segidds = sname + "_" + str((float(ds)/1000))+ sunit
            segidus = sname + "_" + str((float(us)/1000))+ sunit
##            segid = sname + "_" + str(x/1000)+ sunit
##            segidds = sname + "_" + str(ds/1000)+ sunit
##            segidus = sname + "_" + str(x/1000)+ sunit
            #arcpy.AddMessage(sname + "_" + str((float(x)/1000))+ sunit)
        else:
            arcpy.AddWarning("sunit is not km")
            segid = sname + "_" + str((x)) + sunit
            segidds = sname + "_" + str((ds))+ sunit
            segidus = sname + "_" + str((us))+ sunit
        row.setValue("Seg_ID",segid)
        
        if x ==0 :
            x = sdistance
            row.setValue("Seg_ID_DS", "start")
            row.setValue("Seg_ID_US", segidus)
           
        else:
##            if float(sdistance) < 1:
            x = float(x) + float(userdistance)
##            else:
##                x = int(x) + int(userdistance)
            row.setValue("Seg_ID_DS", segidds)
            if r == 1:
                row.setValue("Seg_ID_US", "end")
            else:
                row.setValue("Seg_ID_US", segidus)

        r = r -1
        rows.updateRow(row)
        row = rows.next()
##    arcpy.CopyRows_management(intable, r"C:\temp\fpztest\KB_CBTest1.gdb\temptablecopy")
    arcpy.Append_management(intable, mastertablename, "NO_TEST")
    arcpy.DeleteRows_management(intable)