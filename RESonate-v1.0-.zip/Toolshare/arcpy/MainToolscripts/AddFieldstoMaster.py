# Create and Setup Master Table

# Import system modules
import sys, string, os, arcpy

def main(FGDBwPath, name):

# Process: Create the empty table
    arcpy.CreateTable_management(FGDBwPath, name + "_MasterTable")

    table = FGDBwPath + "//" + name + "_MasterTable"   
    # Process: Add attribute fields to table

    #Add SegmentID Field
    arcpy.AddField_management(table, "Seg_ID", "TEXT", "", "", "50", "Segment ID", "NULLABLE", "NON_REQUIRED", "")
    #Add Units Field
    arcpy.AddField_management(table, "Units", "TEXT", "", "", "5", "Units", "NULLABLE", "NON_REQUIRED", "")
    #Add Mean Precipitation Field
    arcpy.AddField_management(table, "MeanAnnPrecip", "DOUBLE", "8", "", "", "Mean Annual Precip", "NULLABLE", "NON_REQUIRED", "")
    #Add Geology Field
    arcpy.AddField_management(table, "Geology", "TEXT", "", "", "50", "Geology", "NULLABLE", "NON_REQUIRED", "")
    #Add the rest of the fields
    FieldList = ['Elev', 'ValWidth', 'ValFlrWidth', 'RatioVWtoFW', 'LftVSl', 'RtVSl', 'DownVSl', 'SinuLCB', 'SinuRCB', 'CBWidth', 'SinuRC', 'Planform', 'Distance']
    AliasList = ['Elevation','Valley Width','Valley Floor Width','Ratio VW to FW','Left Valley Slope','Right Valley Slope','Down V Slope', 'Sinu L CB','Sinu R CB','Channel Belt Width', 'Sinu RC','Planform', 'SampleDist']
    for f,a in zip(FieldList, AliasList):
    #for f, a in FieldList.iteritems():
        arcpy.AddField_management(table, f, "DOUBLE", "8", "", "", a, "NULLABLE", "NON_REQUIRED", "")
        
    arcpy.AddField_management (table, "StreamName", "TEXT", "", "", "100", "StreamName", "NULLABLE", "NON_REQUIRED", "")
    arcpy.AddField_management(table, "Seg_ID_US", "TEXT", "", "", "50", "Segment ID Up", "NULLABLE", "NON_REQUIRED", "")
    arcpy.AddField_management(table, "Seg_ID_DS", "TEXT", "", "", "50", "Segment ID Down", "NULLABLE", "NON_REQUIRED", "")