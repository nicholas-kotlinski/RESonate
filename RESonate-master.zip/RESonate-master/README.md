# RESonate
RESonate (Riverine Ecosystem Synthesis) geoprocessing methodology for (semi) rapid analysis and categorization of river systems based on hydrogeomorphic variables. ArcPy based scripts for use in ArcGIS
